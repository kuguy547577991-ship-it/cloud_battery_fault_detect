"""Regenerate human-readable reports and compare completed experiment outputs."""
from __future__ import annotations

import json
from pathlib import Path

from battery_warning.config import write_json
from battery_warning.report import create_report, pct
from battery_warning.evaluation import aggregate_metrics


def main() -> None:
    root = Path("outputs")
    runs = {}
    for name in ["default", "normal_holdout", "seed_20260918", "full_soc"]:
        path = root / name / "metrics.json"
        if path.exists():
            summary = json.loads(path.read_text(encoding="utf-8"))
            create_report(root / name, summary)
            runs[name] = summary
    labels = {"default": "基础复现：训练内校准（含明示参数假设）",
              "normal_holdout": "工程对照：独立正常校准",
              "seed_20260918": "独立正常校准：另一随机种子",
              "full_soc": "独立正常校准：全SOC，仅A/D车辆"}
    rows = ["# 实际运行结果汇总", "",
            "全部结果来自本项目生成的虚拟数据。基础复现与工程对照分开报告；不代表原文实车指标重现。", "",
            "| 实验 | 种子 | 车辆数 | Precision | Recall | F1 | 单体窗口FAR | 严重召回 |",
            "|---|---:|---:|---:|---:|---:|---:|---:|"]
    for name, summary in runs.items():
        m = summary["aggregate"]["warning_micro"]
        rows.append(f"| {labels[name]} | {summary['seed']} | {len(summary['vehicles'])} | "
                    f"{pct(m['precision'])} | {pct(m['recall'])} | {pct(m['f1'])} | {pct(m['far'])} | "
                    f"{pct(summary['aggregate']['critical_recall_micro'])} |")
    rows += ["", "注意：全SOC实验仅包含A/D，不能与四车合计直接比较；见下方同车范围对照。", ""]
    if "normal_holdout" in runs and "full_soc" in runs:
        names = list(runs["full_soc"]["vehicles"])
        selected = {n: runs["normal_holdout"]["vehicles"][n] for n in names}
        a = aggregate_metrics(selected)["warning_micro"]
        b = runs["full_soc"]["aggregate"]["warning_micro"]
        rows += ["## 相同A/D车辆的SOC消融", "",
                 f"筛选SOC：F1={pct(a['f1'])}，FAR={pct(a['far'])}；全SOC：F1={pct(b['f1'])}，FAR={pct(b['far'])}。",
                 "两种设置的窗口集合与覆盖率不同，这不是严格相同测试样本的配对比较。", ""]
        for name in names:
            x, y = selected[name], runs["full_soc"]["vehicles"][name]
            rows.append(f"- {name}：筛选/全SOC测试窗口覆盖率 "
                        f"{pct(x['coverage']['test_window_covered_fraction'])}/{pct(y['coverage']['test_window_covered_fraction'])}。")
    rows += ["", "## 结果解读", "",
             "- 基础复现保留论文的训练内尾部校准解释。它能检出注入故障，但误报明显，未达到本项目FAR≤1%的目标；不能宣称已成功复现论文低误报率。",
             "- 频域DBSCAN过滤掉较多正常样本，训练内密度又包含自身核贡献，这会使正常测试样本的尾部分数偏大。独立正常校准对照用于检验这一问题，不使用测试标签调参。",
             "- 独立正常校准仅改变正常期的拟合/校准组织方式，不改变0.4/0.8阈值、故障标签或故障注入幅度。",
             "- 同车电芯池化、SOC上界分位数、DTW配置等仍是未获作者代码确认的假设；不能把对照改善全部归因于原论文算法。",
             "- 报告的低单体误报率不等于低整包报警频率，务必阅读各车pack_false_warning_window_rate。",
             "- 1%尾部通过跨电芯池化获得足够数量，但池化样本有相关性，不能因此认为概率已经校准。", "",
             ]
    if "normal_holdout" in runs and "seed_20260918" in runs:
        first = runs["normal_holdout"]["vehicles"]
        second = runs["seed_20260918"]["vehicles"]
        if "C_mild" in first and "C_mild" in second:
            rows.append(f"- 轻度异常C车的窗口召回随种子从 {pct(first['C_mild']['warning']['recall'])} "
                        f"降至 {pct(second['C_mild']['warning']['recall'])}，说明弱故障检出尚不稳健；事件至少一次检出不能替代窗口召回。")
        if "D_healthy" in first:
            rows.append(f"- 第一个种子的正常D车，任一电芯预警的整包窗口比例仍为 "
                        f"{pct(first['D_healthy']['pack_false_warning_window_rate'])}。低单体FAR不能直接满足实际整包报警要求。")
    rows += ["", "## 详细报告", ""]
    for name in runs:
        rows.append(f"- [{labels[name]}]({name}/validation_report.html)，原始指标见 `{name}/metrics.json`。")
    rows += ["", "自动化测试：在项目根目录运行 `.venv/Scripts/python.exe -m pytest -q`。", ""]
    (root / "实验结果汇总.md").write_text("\n".join(rows), encoding="utf-8")
    write_json(root / "comparison.json", {name: {"seed": s["seed"], "vehicles": list(s["vehicles"]),
                                                 "aggregate": s["aggregate"], "checks": s["checks"]}
                                           for name, s in runs.items()})
    print(f"Compared {len(runs)} completed experiments. See outputs/")


if __name__ == "__main__":
    main()
