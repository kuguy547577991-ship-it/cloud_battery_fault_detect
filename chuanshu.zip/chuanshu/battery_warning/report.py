from __future__ import annotations

from html import escape
from pathlib import Path


def pct(value: float | None) -> str:
    return "N/A" if value is None else f"{100 * value:.2f}%"


def create_report(output: Path, summary: dict) -> None:
    aggregate = summary["aggregate"]["warning_micro"]
    lines = ["# 虚拟数据上的 KDE-EVT 复现与验证", "",
             "本报告由实际运行结果自动生成。仅验证合成电压特征上的方法行为，不代表原文实车指标复现或真实故障概率校准。", "",
             f"随机种子：{summary['seed']}。每车各自训练，前 30% 数据用于正常基线，测试期独立计算指标。",
             f"尾部校准模式：{summary.get('calibration_mode', 'training_inlier')}；SOC 筛选启用：{summary.get('use_soc', True)}。", "",
             "## 测试集结果", "",
             "| 车辆 | 测试窗口 | Precision | Recall | F1 | 单体窗口 FAR | 严重故障 Recall | SOC 区间 |",
             "|---|---:|---:|---:|---:|---:|---:|---|"]
    for name, v in summary["vehicles"].items():
        m = v["warning"]
        soc_range = (f"[{v['soc']['lower_soc']}, {v['soc']['upper_soc_exclusive']})%"
                     if summary.get("use_soc", True) else "全部SOC")
        lines.append(f"| {name} | {v['test_windows']} | {pct(m['precision'])} | {pct(m['recall'])} | "
                     f"{pct(m['f1'])} | {pct(m['far'])} | {pct(v['critical_recall'])} | "
                     f"{soc_range} |")
    lines += ["", f"全车 micro：Precision={pct(aggregate['precision'])}，Recall={pct(aggregate['recall'])}，"
               f"F1={pct(aggregate['f1'])}，FAR={pct(aggregate['far'])}。",
              f"严重故障 micro Recall={pct(summary['aggregate']['critical_recall_micro'])}。", "",
              "普通检测：窗口末端标签>0 且阈值为 0.4；严重故障召回：标签=2 时检查阈值 0.8。未定义指标记 N/A。",
              "Micro 先合并混淆矩阵；macro 对各车已定义 F1 求平均。健康车可能因误报得到 F1=0；无正例且无报警时 F1=N/A。", "",
              "## 可重复验证检查", "", "| 检查 | 结果 |", "|---|---|"]
    for key, value in summary["checks"].items():
        lines.append(f"| {key} | {'PASS' if value else 'FAIL'} |")
    lines += ["", "性能阈值是本项目预先设定的合成数据验收目标，不是论文给出的保证；FAIL 同样保留并报告。", "",
              "## 覆盖率、误报与故障事件", ""]
    for name, v in summary["vehicles"].items():
        lines += [f"### {name}", "",
                  f"测试原始记录 SOC 保留率：{pct(v['coverage']['test_soc_retained_fraction'])}；"
                  f"至少进入一个完整测试窗口的记录比例：{pct(v['coverage']['test_window_covered_fraction'])}。",
                  f"全包正常窗口中，任一电芯产生预警的比例：{pct(v['pack_false_warning_window_rate'])}。"
                  f"故障窗口 top-1 定位召回：{pct(v['top1_localization_recall'])}。", ""]
        for event in v["events"]:
            delay = event["warning_delay_seconds"]
            lead = event["warning_lead_to_injected_severe_hours"]
            lines.append(f"- 电芯 {event['cell_id']} / {event['kind']}：首次预警延迟 "
                         f"{('未检出' if delay is None else f'{delay / 60:.1f} min')}；"
                         f"相对人为设定严重阶段的提前量 {('N/A' if lead is None else f'{lead:.2f} h')}；"
                         f"故障前误报窗口 {event['pre_onset_false_warning_windows']} 个。")
        lines += ["", f"![{name} overview](figures/{name}_overview.png)", "",
                  f"![{name} SOC](figures/{name}_soc.png)", "",
                  f"![{name} tail](figures/{name}_tail_fit.png)", ""]
    if summary.get("counterfactual"):
        cf = summary["counterfactual"]
        lines += ["## 成对反事实验证", "",
                  "只移除 A 车的已知故障注入，保留相同噪声、工况、电芯差异、训练模型和窗口；不重新拟合模型。",
                  f"故障电芯在故障后的平均风险分数：有注入 {cf['fault_cell_mean_with_injection']:.4f}，"
                  f"移除注入 {cf['fault_cell_mean_without_injection']:.4f}。",
                  f"移除注入后的测试单体窗口 FAR={pct(cf['warning_far'])}。", "",
                  "![Counterfactual](figures/A_progressive_counterfactual.png)", ""]
    lines += ["## 原文设定、实现假设和局限", "",
              "- 原文设定：窗口100/步长50、Z-score、DBSCAN(0.5,3)、Gaussian KDE、1%尾部、等权融合、阈值0.4/0.8。",
              "- 实现假设：同车跨电芯池化；DTW分4段，绝对值局部代价且路径不归一化；db4四层+symmetric；Welch 50/25点、Hann窗、自然对数谱熵。",
              "- SOC 阈值仍用 max(lambda*平均一致性, Sl)，Sl 采用训练 SOC 分箱分数的配置分位数。默认0.75是明确补充假设，改为1.0可测试字面最大值解释。",
              "- 默认不跨时间断点和训练/测试分界切窗。SOC选择、标准化、DBSCAN、KDE和GPD只使用训练期。",
              "- training_inlier：对DBSCAN保留的训练样本进行训练内尾部校准；normal_holdout：正常期前半段拟合，后半段全部正常窗口校准，并清除交叉重叠窗口。后者是明确的工程对照，不是声称作者采用的做法。",
              "- GPD仅使用正超额，loc固定0；最少30个尾部样本，否则报错，不自动降级。",
              "- 同车电芯和重叠窗口并非独立；尾部样本数不等于有效独立样本数，P-P图只是诊断。",
              "- 被SOC排除的数据是未评估，不能记为正常。本报告单独报告SOC保留率和窗口覆盖率。",
              "- 轻度不一致未必能跨三个域同时形成高分；等权融合会抑制仅一个域响应的异常。",
              "- 合成信号未模拟电化学短路电流或热失控动力学；分数不等于真实故障发生概率。", "",
              "## 产物", "",
              "- metrics.json：混淆矩阵、每车指标、事件、覆盖率、尾部样本量及检查结果。",
              "- scores/：测试集电芯×窗口明细CSV.gz，包含分域log-density/gap/概率、融合分数和标签。",
              "- features/：全部窗口特征、训练标识、原始清洗后索引和起止时间。",
              "- models/：每车模型与SOC选择器（joblib，仅加载可信本地模型）。",
              "- resolved_config.json、environment.json：配置与运行环境。", ""]
    text = "\n".join(lines)
    (output / "validation_report.md").write_text(text, encoding="utf-8")
    # Safe renderer for the small Markdown subset produced above; no raw HTML.
    html_blocks = []
    i = 0
    while i < len(lines):
        line = lines[i]
        if line.startswith("|"):
            rows = []
            while i < len(lines) and lines[i].startswith("|"):
                cells = [cell.strip() for cell in lines[i].strip("|").split("|")]
                if not all(set(cell) <= set("-: ") for cell in cells):
                    tag = "th" if not rows else "td"
                    rows.append("<tr>" + "".join(f"<{tag}>{escape(cell)}</{tag}>" for cell in cells) + "</tr>")
                i += 1
            html_blocks.append('<div class="table-wrap"><table>' + "".join(rows) + "</table></div>")
            continue
        if line.startswith("!["):
            src = line.split("](", 1)[1][:-1]
            html_blocks.append(f'<img src="{escape(src)}" alt="Verification figure">')
        elif line.startswith("#"):
            level = len(line) - len(line.lstrip("#"))
            html_blocks.append(f"<h{level}>" + escape(line[level:].strip()) + f"</h{level}>")
        elif line.startswith("- "):
            html_blocks.append('<p class="item">• ' + escape(line[2:]) + "</p>")
        elif line.strip():
            html_blocks.append("<p>" + escape(line) + "</p>")
        else:
            html_blocks.append("")
        i += 1
    html = '<!doctype html><html lang="zh-CN"><meta charset="utf-8"><title>KDE-EVT 验证报告</title>'
    html += '<style>body{max-width:1200px;margin:32px auto;padding:0 20px;background:#f7f9fc;color:#203040;font:15px/1.8 "Microsoft YaHei",sans-serif}h1{font-size:30px}h2{margin-top:40px;border-bottom:1px solid #d7e0eb}h3{margin-top:28px}img{width:100%;background:white;margin:12px 0;border-radius:8px}.table-wrap{overflow:auto}table{border-collapse:collapse;width:100%;background:white;font-size:14px}th,td{padding:10px 12px;border-bottom:1px solid #dce3ec;text-align:left;white-space:nowrap}th{background:#e6edf5}.item{margin:6px 0}</style>'
    html += "<body>" + "\n".join(html_blocks) + "</body></html>"
    (output / "validation_report.html").write_text(html, encoding="utf-8")
