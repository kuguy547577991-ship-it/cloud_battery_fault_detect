from __future__ import annotations

from pathlib import Path
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from scipy.stats import genpareto

plt.rcParams.update({"font.size": 10, "axes.spines.top": False,
                     "axes.spines.right": False, "figure.dpi": 120})


def plot_vehicle(destination: Path, vehicle: str, data, selector, batch,
                 scores: dict, model, metadata: dict, cutoff_s: float, use_soc: bool = True) -> None:
    destination.mkdir(parents=True, exist_ok=True)
    hours = data.time_s / 3600
    wh = batch.end_s / 3600
    fault_cells = [e["cell_id"] - 1 for e in metadata["events"]]
    normal_cells = [i for i in range(data.voltage_v.shape[1]) if i not in fault_cells]
    colors = ["#d1495b", "#00798c"]
    fig, ax = plt.subplots(3, 1, figsize=(12, 9), sharex=True, constrained_layout=True)
    stride = max(1, len(hours) // 5000)
    sample = np.arange(0, len(hours), stride)
    median = np.median(data.voltage_v, axis=1)
    delta = (data.voltage_v - median[:, None]) * 1000
    low, high = np.percentile(delta[:, normal_cells], [1, 99], axis=1)
    ax[0].fill_between(hours[sample], low[sample], high[sample], color="#d5dde5", label="Healthy cells: 1-99% band")
    for i, cell in enumerate(fault_cells):
        ax[0].plot(hours[sample], delta[sample, cell], color=colors[i], linewidth=0.8, label=f"Cell {cell + 1}")
    ax[0].set_ylabel("Voltage residual (mV)")
    ax[0].set_title(f"{vehicle} | Synthetic voltage signatures; training-only fit")
    ax[0].legend(loc="lower left", ncol=3)
    ax[1].plot(hours[sample], data.soc[sample], color="#457b9d", linewidth=0.8)
    if use_soc:
        ax[1].axhspan(selector.lower, selector.upper, alpha=0.16, color="#2a9d8f", label="Selected SOC")
    else:
        ax[1].plot([], [], color="#457b9d", label="Full SOC: screening disabled")
    ax[1].set_ylabel("SOC (%)")
    ax[1].legend(loc="upper right")
    p = scores["fused"]
    ax[2].axhspan(0, 0.4, color="#eef8ee")
    ax[2].axhspan(0.4, 0.8, color="#fff5ce")
    ax[2].axhspan(0.8, 1, color="#fde5e6")
    ax[2].plot(wh, p[:, normal_cells].max(axis=1), color="#8293a1", alpha=0.8,
               linewidth=0.8, label="Maximum of healthy cells")
    for i, cell in enumerate(fault_cells):
        ax[2].plot(wh, p[:, cell], color=colors[i], linewidth=1.2, label=f"Cell {cell + 1}")
    ax[2].axhline(0.4, color="#8c7b30", linestyle="--", linewidth=0.8)
    ax[2].axhline(0.8, color="#a04b4b", linestyle="--", linewidth=0.8)
    ax[2].set(ylabel="Fused anomaly score", xlabel="Elapsed wall-clock time (h)", ylim=(-0.03, 1.03))
    ax[2].legend(loc="upper left", ncol=3)
    for a in ax:
        a.axvspan(0, cutoff_s / 3600, color="#708090", alpha=0.12)
        a.axvline(cutoff_s / 3600, color="#34495e", linestyle=":", linewidth=1)
        for event in metadata["events"]:
            a.axvline(event["onset_time_s"] / 3600, color="#d1495b", linestyle=":", alpha=0.6)
        a.grid(alpha=0.15)
    fig.savefig(destination / f"{vehicle}_overview.png")
    plt.close(fig)

    fig, ax = plt.subplots(1, 2, figsize=(12, 4), constrained_layout=True)
    ax[0].plot(selector.bins, selector.scores * 1000, ".-", alpha=0.5, label="Training bin score")
    ax[0].plot(selector.bins, selector.smooth * 1000, color="#e76f51", label="S-G smoothed")
    ax[0].axhline(selector.threshold * 1000, color="#333333", linestyle="--", label="Selection threshold")
    ax[0].axvspan(selector.lower, selector.upper, color="#2a9d8f", alpha=0.15)
    ax[0].set(xlabel="SOC (%)", ylabel="Mean cell spread (mV)", title="SOC selection fitted on training only")
    if not use_soc:
        ax[0].set_title("Diagnostic selector only; not applied in this ablation")
    ax[0].legend(fontsize=8)
    selected = selector.mask(data.soc)
    train = data.time_s < cutoff_s
    spread = data.voltage_v.std(axis=1) * 1000
    ax[1].hist(spread[train], bins=40, alpha=0.45, density=True, label="All training records")
    ax[1].hist(spread[train & selected], bins=30, alpha=0.6, density=True, label="Selected training records")
    ax[1].set(xlabel="Cell spread (mV)", ylabel="Density", title="Baseline consistency before / after screening")
    ax[1].legend(fontsize=8)
    fig.savefig(destination / f"{vehicle}_soc.png")
    plt.close(fig)

    fig, axes = plt.subplots(1, 3, figsize=(12, 3.8), constrained_layout=True)
    for ax, (name, domain) in zip(axes, model.domains.items()):
        tail = np.sort(domain.exceedances)
        empirical = np.arange(1, len(tail) + 1) / (len(tail) + 1)
        fitted = genpareto.cdf(tail, domain.shape, scale=domain.scale)
        ax.plot(fitted, empirical, ".", color="#00798c")
        ax.plot([0, 1], [0, 1], "--", color="#888888")
        ax.set(xlabel="Fitted GPD CDF", ylabel="Empirical tail CDF",
               title=f"{name}: n_tail={len(tail)}, xi={domain.shape:.2f}")
    fig.suptitle("Descriptive tail fit: pooled, overlapping samples; not a calibration proof")
    fig.savefig(destination / f"{vehicle}_tail_fit.png")
    plt.close(fig)


def plot_counterfactual(destination: Path, end_s: np.ndarray, actual: np.ndarray,
                        counterfactual: np.ndarray, cell: int) -> None:
    fig, ax = plt.subplots(figsize=(11, 3.8), constrained_layout=True)
    ax.plot(end_s / 3600, actual[:, cell], label="Injected fault", color="#d1495b")
    ax.plot(end_s / 3600, counterfactual[:, cell], label="Same latent data, fault injection removed", color="#00798c")
    ax.axhline(0.4, linestyle="--", color="#8c7b30")
    ax.set(xlabel="Elapsed time (h)", ylabel="Fused anomaly score", ylim=(-0.03, 1.03),
           title=f"Counterfactual validation: cell {cell + 1}; same fitted model")
    ax.legend()
    fig.savefig(destination / "A_progressive_counterfactual.png")
    plt.close(fig)
