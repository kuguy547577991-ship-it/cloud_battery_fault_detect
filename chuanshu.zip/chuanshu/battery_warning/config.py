from __future__ import annotations

import json
from pathlib import Path
import numpy as np


def load_config(path: str | Path) -> dict:
    config = json.loads(Path(path).read_text(encoding="utf-8"))
    m, s = config["method"], config["simulation"]
    if not 0 < m["train_fraction"] < 0.5:
        raise ValueError("train_fraction must be between 0 and 0.5")
    if m["window_length"] % m["dtw_segments"]:
        raise ValueError("window_length must be divisible by dtw_segments")
    if m["window_policy"] not in {"contiguous", "concatenate"}:
        raise ValueError("Unknown window_policy")
    if not 0 < m["tail_quantile"] < 0.5:
        raise ValueError("Invalid tail_quantile")
    if m.get("calibration_mode", "training_inlier") not in {"training_inlier", "normal_holdout"}:
        raise ValueError("Unknown calibration mode")
    if not 0 < m.get("calibration_fraction", 0.5) < 1:
        raise ValueError("Invalid calibration fraction")
    if not 0 <= m["warning_threshold"] < m["alarm_threshold"] <= 1:
        raise ValueError("Invalid risk thresholds")
    if s["n_cells"] < 8 or s["n_samples"] < 2000:
        raise ValueError("Simulation requires at least 8 cells and 2000 samples")
    return config


def write_json(path: str | Path, obj: object) -> None:
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    def numpy_to_builtin(value):
        if isinstance(value, np.generic):
            return value.item()
        if isinstance(value, np.ndarray):
            return value.tolist()
        raise TypeError(f"Cannot serialize {type(value).__name__}")

    path.write_text(json.dumps(obj, indent=2, ensure_ascii=False, allow_nan=False,
                               default=numpy_to_builtin), encoding="utf-8")
