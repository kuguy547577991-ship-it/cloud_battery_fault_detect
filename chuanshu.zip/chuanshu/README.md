# 电池概率故障预警：虚拟数据复现

对应论文：Song et al., *Unsupervised probabilistic fault detection and risk quantification for lithium-ion batteries in real-world electric vehicles*, Energy Storage Materials 90 (2026), 105326。

本项目已实现虚拟数据生成、清洗、训练期自适应 SOC 筛选、统计/DTW/小波与谱熵特征、DBSCAN、分域 KDE-GPD、风险融合与验证。**这是注明假设的方法复现，不是作者源代码，也不是原文真实车辆指标复现。**

## 一键运行

在本目录打开 PowerShell。已建立独立 `.venv`，不修改原 Anaconda 环境。

```powershell
# 首次配置（当前目录已完成）
uv venv --python 3.12 .venv
uv pip install --python .venv/Scripts/python.exe -r requirements.txt

# 生成数据、训练、评分、成对反事实验证和图表报告
.venv/Scripts/python.exe run_reproduction.py all

# 有数据时仅重新运行方法
.venv/Scripts/python.exe run_reproduction.py run

# 独立正常校准对照（工程扩展，保留默认基础复现结果）
.venv/Scripts/python.exe run_reproduction.py run --config configs/normal_holdout.json --output outputs/normal_holdout

# 自动化检查
.venv/Scripts/python.exe -m pytest -q

# 汇总已完成的实验并生成对比说明
.venv/Scripts/python.exe summarize_results.py
```

没有 uv 时可用 Python 3.12 的 `python -m venv .venv`，然后 `.venv/Scripts/python.exe -m pip install -r requirements.txt`。完整四车运行可能需要数分钟，取决于 CPU 和磁盘。

入口默认以当前目录解析路径，请在项目根目录执行。`all` 会按固定种子重新生成 `data/synthetic`，并更新 `outputs/default`；实验变体请指定独立目录。

## 文件与输出

| 文件/目录 | 内容 |
|---|---|
| `configs/default.json` | 全部数据生成参数和方法超参数 |
| `battery_warning/synthetic.py` | 已知故障注入与独立真值标签 |
| `preprocess.py`、`soc.py` | 清洗、缺失处理、训练期 SOC 区间 |
| `features.py` | 精确 DTW、统计特征、db4 能量、Welch 谱熵 |
| `model.py` | 正常样本池、DBSCAN、KDE、GPD 与风险融合 |
| `evaluation.py` | 测试集指标、电芯定位、故障事件时延 |
| `pipeline.py`、`plots.py`、`report.py` | 完整运行、可视化、自动报告 |
| `tests/test_reproduction.py` | 数值、边界、数据切分和模型行为检查 |
| `data/synthetic/*.npz` | 四辆虚拟车的原始数据 |
| `data/synthetic/*.json` | 生成机制、随机种子、故障电芯和注入时刻 |
| `outputs/default/validation_report.html` | 可直接用浏览器打开的图文验证报告 |
| `outputs/default/validation_report.md` | 同内容 Markdown 报告 |
| `outputs/default/metrics.json` | 完整指标、覆盖率、混淆矩阵、尾部诊断和验收检查 |
| `outputs/default/scores/*.csv.gz` | 测试集逐电芯逐窗口得分和标签 |
| `outputs/default/features/*.npz` | 窗口特征、时间、索引、训练标记 |
| `outputs/default/models/*.joblib` | 保存的模型和 SOC 选择器，仅加载可信本地文件 |
| `outputs/实验结果汇总.md` | 基础复现、正常留出校准、独立种子与SOC消融的实际结果对照 |

`scores/*.csv.gz` 是压缩文本明细，可用 Python `gzip` / `csv` 或 pandas 读取。未安装 pandas 不影响本项目运行。

`configs/default.json` 保留训练内尾部校准；`configs/normal_holdout.json` 只修改正常校准方式，将正常期后50%的窗口独立用于尾部校准，剔除与其重叠的拟合窗口。它用于验证训练内评分和DBSCAN过滤带来的偏差，不声称属于作者原实现。两组结果分开保存，不覆盖或隐藏基础复现误报。

## 1. 虚拟数据设计

默认每车 24,000 个规则时刻、96 个串联电芯、10 s 采样、1 mV 量化。时间范围约 66.7 小时，SOC 在 5%-95% 循环。模拟共同 OCV、充放电负载、电芯偏置/电阻差异、SOC 两端增强的极化差异、自相关噪声和测量噪声。

| 车辆 | 已知注入 | 电芯 | 开始 / 严重阶段 |
|---|---|---|---|
| A_progressive | 渐进压降与增长的振荡 | #74 | 总时序55% / 82% |
| B_two_faults | 缓慢负向漂移；间歇压降 | #2；#49 | 50%与65% / 均85% |
| C_mild | 最大约6 mV的持续轻度偏差 | #20 | 58% / 无严重阶段 |
| D_healthy | 无故障，保留所有正常工况变化 | 无 | 无 |

前30%全部无故障。注入时间和幅度由生成器预先规定，不根据模型检测结果倒推标签。原始文件故意含重复、乱序、短/长缺失、负电压和非法SOC，用于验证清洗。

这些是“类似故障的电压签名”，没有实际计算内短路电阻、自放电电流、温升或热失控。`labels`：0正常、1注入早期异常、2人为设定严重阶段。

NPZ字段：`time_s`、`soc`、`current_a`、`voltage_v`、`labels`、`normal_voltage_v`、`fault_delta_v`、`original_index`。`normal_voltage_v` 为相同随机背景下的无故障对照；仅用于反事实验证，检测器不读取它作为训练信息。

## 2. 对照论文的实现约定

| 项目 | 当前实现 | 证据层级 |
|---|---|---|
| 窗长/步长 | 100/50点 | 原文明确 |
| 电压参考 | 同时刻包内电芯中位数 | 原文明确 |
| 统计特征 | 有符号均值、总体标准差、绝对残差中位数 | 原文明确 |
| DTW特征 | 分段距离均值、全包全子段标准化后的最大值 | 原文框架；标准化池范围按字面解释 |
| DTW实现 | 4段×25点；绝对值代价；精确动态规划；不按路径归一化 | 补充假设 |
| 频域 | db4四层，A4/D4/D3/D2/D1能量+谱熵 | db4原文明确；四层由6维输入推断 |
| 小波边界 | symmetric | 补充假设；100点四层存在边界效应 |
| Welch | fs=1/采样间隔；50点、重叠25点、Hann窗、去均值 | 补充假设 |
| 谱熵 | PSD归一化成离散概率质量，用自然对数 | 明确离散实现 |
| 标准化/DBSCAN | Z-score；eps=.5、MinPts=3；保留所有非噪声簇 | 原文明确 |
| 模型粒度 | 每车、每域跨电芯合并正常窗口 | 明确补充假设，解决单电芯尾部过少 |
| KDE | Gaussian、各向同性Silverman带宽，公式见代码 | 原文规则，具体形式明确化 |
| GPD | 正常log-density的1%左尾；仅正超额；固定loc=0 | 原文框架，拟合细节明确化 |
| 尾部校准 | DBSCAN保留训练样本的训练内评分 | 原文可行解释，不是独立校准 |
| 融合与分级 | 三域平均；.4预警/.8报警 | 原文明确 |

**没有使用测试标签训练、选参数或调整阈值。** 测试标签只用于报告。GPD尾部必须至少30个样本、非退化且拟合有效，否则明确失败，不输出伪装成功的概率。

SOC阈值实现 `T=max(lambda*mean(spread), Sl)`，`lambda=0.9`。原文未公开 Sl 的精确定义，当前将其设为训练 SOC 分箱分数的0.75分位数，作为典型正常范围的稳健上界；**这是工程假设，不是已确认的作者值**。若要测试“全SOC最大值”的字面解释，将 `soc_floor_quantile` 改为1.0并用独立输出目录比较。

SOC选择器仅在训练期拟合。默认 `window_policy=contiguous`，不跨缺失段、SOC筛选产生的时间断点或训练/测试边界。`concatenate` 可以研究论文文字所暗示的保留点拼接，但频谱此时不再对应规则真实时间，必须单独解释。

## 3. 验证内容和统计口径

- 使用前30%规则时间范围训练，测试期窗口独立评分；每车独立拟合。
- 普通检测：窗口末端故障标签>0，融合分数≥0.4。
- 严重故障召回：窗口末端标签=2，融合分数≥0.8。
- 输出 per-vehicle 与 micro 混淆矩阵、F1/Recall/Precision/FAR；未定义指标记null/N/A。
- 另报全包正常窗口任一电芯误报率，避免只展示低单体FAR。
- 记录首次故障后预警、报警、三窗确认时刻；同时保留故障前误报次数。
- 所有时延用真实时间戳，不以窗口编号差替代。
- SOC排除的记录属于未评估，报告保留率和完整窗口覆盖率，不记为TN。
- 保存每域DBSCAN保留率、尾部数量、GPD参数及P-P图。
- 单域消融直接读取三域分数，见 `metrics.json` 的 `domain_ablation`。
- A车额外执行成对反事实：相同模型、噪声、工况和窗口，仅移除已知故障注入，检查目标电芯风险是否下降。

自动检查包含有限数值、时间隔离、最小尾部样本、全部注入事件检出、单体FAR≤1%、反事实风险下降。性能检查的PASS/FAIL原样保留，不为通过验收隐藏失败结果。尾部样本相关性、模型失配和训练内评分偏差仍存在，不能用P-P图证明真实概率校准。

## 4. 消融与独立种子

```powershell
# 全SOC基线：共享虚拟数据，其余配置不变
.venv/Scripts/python.exe run_reproduction.py run --no-soc --no-counterfactual --output outputs/full_soc_training_inlier

# 独立随机种子：独立数据和结果目录
.venv/Scripts/python.exe run_reproduction.py all --seed 20260918 --data-dir data/seed_20260918 --output outputs/seed_20260918_training_inlier --no-counterfactual

# 只运行某辆车
.venv/Scripts/python.exe run_reproduction.py run --vehicles C_mild --no-counterfactual --output outputs/mild_only
```

更多消融可复制配置：小波层数3/4、SOC上界分位数、分段数量、尾部比例、是否拼接时间片段。每次明确记录偏离论文默认设置的内容，不能用测试集挑选最优配置后仍称无偏测试。

本次交付的 `outputs/full_soc` 实际使用正常留出校准，并只比较A/D两车；`outputs/seed_20260918` 也使用正常留出校准。精确重跑命令如下，避免与上方基础版本示例混淆：

```powershell
.venv/Scripts/python.exe run_reproduction.py run --config configs/normal_holdout.json --no-soc --no-counterfactual --vehicles A_progressive D_healthy --output outputs/full_soc
.venv/Scripts/python.exe run_reproduction.py all --config configs/normal_holdout.json --seed 20260918 --data-dir data/seed_20260918 --output outputs/seed_20260918 --no-counterfactual
```

## 5. 接入自己的数据

核心接口不要求故障标签：

```python
from battery_warning.preprocess import clean_records
from battery_warning.soc import fit_soc_selector
from battery_warning.features import extract_features
from battery_warning.model import BatteryRiskModel

# time_s: [T]，soc: [T]（0-100），voltage_v: [T,N]（V）
clean = clean_records(time_s, soc, voltage_v, sample_seconds=10)
train = clean.time_s < known_normal_cutoff_s
selector = fit_soc_selector(clean.soc[train], clean.voltage_v[train], cfg)
batch = extract_features(clean.time_s, clean.voltage_v,
                         selector.mask(clean.soc), known_normal_cutoff_s, 10, cfg)
model = BatteryRiskModel(cfg).fit(batch.values[batch.train])
scores = model.score(batch.values[~batch.train])
```

要求固定电芯编号、同步电压、明确采样网格和可信正常期。`clean_records` 针对规则采样网格；时间戳偏离网格会明确报错，真实不规则数据需先制定重采样规则。在线短缺失插值需要等待后端点，不能把当前离线验证直接等同于无延迟在线部署。

不应把 `scores['fused']=0.8` 解释为真实事故发生概率80%。它是正常尾部偏离分数。原文结果、缺失参数和统计解释详见同目录《文献分析与复现路线.md》。

## 参考实现文档

- [论文 DOI](https://doi.org/10.1016/j.ensm.2026.105326)
- [scikit-learn KernelDensity](https://scikit-learn.org/stable/modules/generated/sklearn.neighbors.KernelDensity.html)
- [SciPy genpareto](https://docs.scipy.org/doc/scipy/reference/generated/scipy.stats.genpareto.html)
- [PyWavelets DWT](https://pywavelets.readthedocs.io/en/latest/ref/dwt-discrete-wavelet-transform.html)

主要依赖版本见 `requirements.txt`，包含传递依赖的实际锁定版本见 `requirements-lock.txt`，实际运行环境见输出目录 `environment.json`。
