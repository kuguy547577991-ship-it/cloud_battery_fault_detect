"""One-command generator, paper-method implementation and synthetic validation."""
from __future__ import annotations

import argparse
from pathlib import Path

from battery_warning.config import load_config
from battery_warning.synthetic import generate_dataset, SCENARIOS
from battery_warning.pipeline import run_experiment


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("command", choices=["generate", "run", "all"], nargs="?", default="all")
    parser.add_argument("--config", default="configs/default.json")
    parser.add_argument("--data-dir", default="data/synthetic")
    parser.add_argument("--output", default="outputs/default")
    parser.add_argument("--seed", type=int, help="Override generator seed; use a separate output directory")
    parser.add_argument("--vehicles", nargs="+", choices=list(SCENARIOS))
    parser.add_argument("--no-counterfactual", action="store_true")
    parser.add_argument("--no-soc", action="store_true", help="Full SOC ablation with all other settings unchanged")
    args = parser.parse_args()
    config = load_config(args.config)
    if args.seed is not None:
        config["seed"] = args.seed
    if args.command in {"generate", "all"}:
        generate_dataset(config, Path(args.data_dir))
    if args.command in {"run", "all"}:
        run_experiment(config, args.data_dir, args.output, not args.no_counterfactual, args.vehicles, not args.no_soc)


if __name__ == "__main__":
    main()
