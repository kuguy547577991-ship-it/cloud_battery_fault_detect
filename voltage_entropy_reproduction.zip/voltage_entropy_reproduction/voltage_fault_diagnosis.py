#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""滑窗 Shannon 熵 + 横向 Z-score 电压异常诊断，全部算法集中在本文件。

文献：Wang et al., Applied Energy 196 (2017), 289-302.
DOI: 10.1016/j.apenergy.2016.12.143

实现的是经过显式纠错的机制复现，不保证重现原文图中数值：
1. 窗口沿时间逐点滑动，共享整个 K×C 窗口的 min/max，等宽分 L 箱。
2. 修订原文分箱分母、求和上限为 L；每窗口输出 C 个电芯熵。
3. 明确采用 log2（可配置），0*log(0)=0，最后一箱包含右端点。
4. 在同窗口跨电芯计算总体标准差 ddof=0，使用 |A| 的 3.5/4 分级。
5. 结果时间戳为窗口末端；缺测整窗无效；长间隔重建窗口。
6. 零标准差无法计算 Z-score，以 NaN、level=0 和状态单独表示。

原文 10 箱与图中部分熵值的矛盾未通过人为缩放掩盖。未增加去抖、
迟滞或物理故障分类；样本熵是论文对照方法，不是本文件的主诊断链。

用法：
    python voltage_fault_diagnosis.py
    python voltage_fault_diagnosis.py --input data/synthetic_low_entropy.csv --plot
依赖：numpy、pandas；--plot 另外需要 matplotlib。
"""

from __future__ import annotations

import argparse
import csv
import hashlib
import json
import math
import re
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Sequence

import numpy as np
import pandas as pd


@dataclass(frozen=True)
class Config:
    """interval/gap 为数据处理约定；其余为熵与分级参数。"""

    window: int = 100
    bins: int = 10
    log_base: float = 2.0
    warning_threshold: float = 3.5
    alarm_threshold: float = 4.0
    std_tolerance: float = 1e-12
    sample_interval_seconds: float = 10.0
    gap_factor: float = 1.5

    def __post_init__(self) -> None:
        for name in ("window", "bins"):
            value = getattr(self, name)
            if isinstance(value, bool) or not isinstance(value, (int, np.integer)) or value < 2:
                raise ValueError(f"{name} 必须是 >=2 的整数")
        for name in ("log_base", "warning_threshold", "alarm_threshold", "std_tolerance",
                     "sample_interval_seconds", "gap_factor"):
            if not math.isfinite(getattr(self, name)):
                raise ValueError(f"{name} 必须为有限数值")
        if self.log_base <= 1:
            raise ValueError("log_base 必须 >1")
        if not 0 <= self.warning_threshold < self.alarm_threshold:
            raise ValueError("阈值必须满足 0 <= warning_threshold < alarm_threshold")
        if self.std_tolerance < 0 or self.sample_interval_seconds <= 0 or self.gap_factor <= 1:
            raise ValueError("std_tolerance>=0、sample_interval_seconds>0、gap_factor>1")


@dataclass
class DiagnosticResult:
    """各矩阵形状均为 (时间点数, 电芯数)，包括尚未满窗的行。"""

    timestamps: pd.DatetimeIndex
    cell_names: list[str]
    entropy: np.ndarray
    zscore: np.ndarray
    levels: np.ndarray  # 0=未评分，1/2/3=论文异常等级
    pack_summary: pd.DataFrame
    config: Config


def window_entropy(voltage_window: np.ndarray, bins: int = 10,
                   log_base: float = 2.0) -> np.ndarray:
    """式(2)-(6)的修订实现：跨时间逐电芯计数，窗口内所有电芯共享箱界。

    输入必须是无 NaN/Inf 的二维数组 (K, C)，电压单位为 V。
    左闭右开分箱；最后一箱右闭。返回长度 C 的熵向量。
    """
    if isinstance(bins, bool) or not isinstance(bins, (int, np.integer)) or bins < 2:
        raise ValueError("bins 必须是 >=2 的整数")
    if not math.isfinite(log_base) or log_base <= 1:
        raise ValueError("log_base 必须是 >1 的有限数")
    values = np.asarray(voltage_window, dtype=float)
    if values.ndim != 2 or min(values.shape) < 1 or not np.isfinite(values).all():
        raise ValueError("voltage_window 必须是非空且全部有限的二维数组")
    rows, cells = values.shape
    vmin, vmax = float(values.min()), float(values.max())
    if vmin == vmax:
        return np.zeros(cells)
    edges = np.linspace(vmin, vmax, bins + 1)
    # 只搜索内部边界，因此 xmin 和 xmax 都会计入合法区间。
    bin_index = np.searchsorted(edges[1:-1], values, side="right")
    # 把 (电芯, 箱) 映射到一个整数，一次 bincount 完成全部电芯计数。
    identifiers = bin_index + bins * np.arange(cells)[None, :]
    counts = np.bincount(identifiers.ravel(), minlength=cells * bins).reshape(cells, bins)
    probabilities = counts / rows
    log_probabilities = np.zeros_like(probabilities)
    np.log(probabilities, out=log_probabilities, where=probabilities > 0)
    return -np.sum(probabilities * log_probabilities, axis=1) / math.log(log_base)


def classify_scores(scores: np.ndarray, warning_threshold: float = 3.5,
                    alarm_threshold: float = 4.0) -> np.ndarray:
    """正负两侧使用同一阈值；3.5 归一级，4 归三级；非有限值归未评分。"""
    if not (math.isfinite(warning_threshold) and math.isfinite(alarm_threshold)
            and 0 <= warning_threshold < alarm_threshold):
        raise ValueError("阈值必须有限且满足 0 <= warning < alarm")
    scores = np.asarray(scores, dtype=float)
    levels = np.zeros(scores.shape, dtype=np.uint8)
    finite = np.isfinite(scores)
    absolute = np.abs(scores)
    levels[finite] = 1
    levels[finite & (absolute > warning_threshold)] = 2
    levels[finite & (absolute >= alarm_threshold)] = 3
    return levels


def entropy_to_scores(entropy: np.ndarray, std_tolerance: float = 1e-12) -> np.ndarray:
    """式(14)、(16)：同一窗口跨电芯标准化；不沿历史时间标准化。"""
    values = np.asarray(entropy, dtype=float)
    if values.ndim != 1 or values.size < 2 or not np.isfinite(values).all():
        raise ValueError("entropy 必须包含至少两个有限电芯熵")
    if not math.isfinite(std_tolerance) or std_tolerance < 0:
        raise ValueError("std_tolerance 必须是非负有限数")
    std = float(values.std(ddof=0))
    if std <= std_tolerance:
        return np.full(values.shape, np.nan)
    return (values - values.mean()) / std


def diagnose_voltage(voltages: np.ndarray, timestamps: Sequence,
                     config: Config | None = None,
                     cell_names: Sequence[str] | None = None) -> DiagnosticResult:
    """对一个包/簇的电压做因果诊断，不读取任何注入标签或未来数据。

    timestamps 必须严格递增且采用一致时区，未满 K 点的行保留 warmup。
    相邻间隔 > sample_interval_seconds*gap_factor 时重新积累 K 个点。
    NaN/Inf 使所有包含它的窗口无效；不会静默插值、删芯或填 0。
    """
    cfg = config or Config()
    values = np.asarray(voltages, dtype=float)
    if values.ndim != 2 or values.shape[0] < 1 or values.shape[1] < 2:
        raise ValueError("voltages 需要至少一行、两个电芯，形状为 (T,C)")
    count, cells = values.shape
    times = pd.DatetimeIndex(pd.to_datetime(timestamps, errors="raise"))
    if len(times) != count or times.hasnans or not times.is_unique or not times.is_monotonic_increasing:
        raise ValueError("时间戳必须与行数一致、无空值、严格递增且不重复")
    names = list(cell_names) if cell_names is not None else [f"cell_{j + 1:03d}" for j in range(cells)]
    if len(names) != cells or len(set(names)) != cells:
        raise ValueError("cell_names 必须与电芯数一致且不重复")

    entropy = np.full(values.shape, np.nan)
    scores = np.full(values.shape, np.nan)
    levels = np.zeros(values.shape, dtype=np.uint8)
    status = np.full(count, "warmup", dtype=object)
    starts = np.full(count, -1, dtype=int)
    means, stds = np.full(count, np.nan), np.full(count, np.nan)
    minimum, maximum = np.full(count, np.nan), np.full(count, np.nan)
    gaps = np.r_[False, np.asarray((times[1:] - times[:-1]).total_seconds()) >
                 cfg.sample_interval_seconds * cfg.gap_factor]
    segment_start = 0

    for end in range(count):
        if gaps[end]:
            segment_start = end
        start = end - cfg.window + 1
        if start < segment_start:
            continue
        starts[end] = start
        window = values[start:end + 1, :]
        if not np.isfinite(window).all():
            status[end] = "invalid_window"
            continue
        minimum[end], maximum[end] = window.min(), window.max()
        entropy[end] = window_entropy(window, cfg.bins, cfg.log_base)
        means[end] = entropy[end].mean()
        stds[end] = entropy[end].std(ddof=0)
        scores[end] = entropy_to_scores(entropy[end], cfg.std_tolerance)
        if stds[end] <= cfg.std_tolerance:
            status[end] = "zero_entropy_std"
            continue
        levels[end] = classify_scores(scores[end], cfg.warning_threshold, cfg.alarm_threshold)
        status[end] = "ok"

    pack_level = levels.max(axis=1)
    max_abs = np.full(count, np.nan)
    valid = status == "ok"
    max_abs[valid] = np.max(np.abs(scores[valid]), axis=1)
    summary = pd.DataFrame({
        "timestamp": times,  # 每个结果的可用时刻 = 窗口末端
        "window_start": [times[i].isoformat() if i >= 0 else "" for i in starts],
        "window_end": [t.isoformat() for t in times],
        "status": status,
        "pack_level": pack_level,
        "max_abs_zscore": max_abs,
        "mean_entropy": means,
        "std_entropy": stds,
        "voltage_min_v": minimum,
        "voltage_max_v": maximum,
        "n_cells": cells,
        "level2_cells": [";".join(names[j] for j in np.flatnonzero(row == 2)) for row in levels],
        "level3_cells": [";".join(names[j] for j in np.flatnonzero(row == 3)) for row in levels],
    })
    return DiagnosticResult(times, names, entropy, scores, levels, summary, cfg)


def extract_events(result: DiagnosticResult) -> pd.DataFrame:
    """将连续二/三级窗口合并以便查看；不改变逐窗判级，也不施加去抖。"""
    columns = ["cell_id", "start_time", "end_time", "n_windows", "span_seconds",
               "max_level", "peak_abs_zscore", "first_level3_time"]
    records = []
    for j, name in enumerate(result.cell_names):
        active = result.levels[:, j] >= 2
        changes = np.diff(np.r_[False, active, False].astype(int))
        for start, stop in zip(np.flatnonzero(changes == 1), np.flatnonzero(changes == -1)):
            alarm_indices = np.flatnonzero(result.levels[start:stop, j] == 3)
            records.append({
                "cell_id": name,
                "start_time": result.timestamps[start].isoformat(),
                "end_time": result.timestamps[stop - 1].isoformat(),
                "n_windows": int(stop - start),
                "span_seconds": (result.timestamps[stop - 1] - result.timestamps[start]).total_seconds(),
                "max_level": int(result.levels[start:stop, j].max()),
                "peak_abs_zscore": float(np.abs(result.zscore[start:stop, j]).max()),
                "first_level3_time": (result.timestamps[start + alarm_indices[0]].isoformat()
                                      if alarm_indices.size else ""),
            })
    return pd.DataFrame(records, columns=columns).sort_values(["start_time", "cell_id"], ignore_index=True)


def load_voltage_csv(path: Path) -> tuple[np.ndarray, pd.DatetimeIndex, list[str]]:
    """读取单包宽表：timestamp,cell_001,...；辅助列不参与诊断。"""
    with path.open("r", encoding="utf-8-sig", newline="") as stream:
        header = next(csv.reader(stream), [])
    if len(header) != len(set(header)):
        raise ValueError(f"{path.name}: CSV 含重复列名")
    frame = pd.read_csv(path)
    if "timestamp" not in frame or frame.empty:
        raise ValueError(f"{path.name}: 需要 timestamp 和至少一行数据")
    names = [name for name in frame.columns if re.fullmatch(r"cell_\d+", name)]
    names.sort(key=lambda name: int(name.split("_")[1]))
    if len(names) < 2 or len({int(name.split('_')[1]) for name in names}) != len(names):
        raise ValueError("至少需要两个不重复的电芯编号列，例如 cell_001、cell_002")
    for group_column in ("asset_id", "vehicle_id", "pack_id", "cluster_id"):
        if group_column in frame and frame[group_column].nunique(dropna=False) != 1:
            raise ValueError(f"{group_column} 含多个组，请先拆分为独立 CSV")
    # 非数值字符串是输入格式错误；真正的空白值作为 NaN 传入窗口质量检查。
    values = frame[names].apply(pd.to_numeric, errors="raise").to_numpy(dtype=float)
    times = pd.DatetimeIndex(pd.to_datetime(frame["timestamp"], errors="raise"))
    return values, times, names


def save_results(result: DiagnosticResult, output_dir: Path, input_path: Path) -> dict:
    output_dir.mkdir(parents=True, exist_ok=True)
    for filename, array in (("entropy.csv", result.entropy), ("zscore.csv", result.zscore),
                            ("cell_levels.csv", result.levels)):
        frame = pd.DataFrame(array, columns=result.cell_names)
        frame.insert(0, "timestamp", result.timestamps)
        frame.to_csv(output_dir / filename, index=False, float_format="%.10g", encoding="utf-8-sig")
    result.pack_summary.to_csv(output_dir / "pack_summary.csv", index=False,
                               float_format="%.10g", encoding="utf-8-sig")
    events = extract_events(result)
    events.to_csv(output_dir / "events.csv", index=False, float_format="%.10g", encoding="utf-8-sig")
    alarms = result.pack_summary[result.pack_summary["pack_level"] == 3]
    theoretical_z_bound = math.sqrt(len(result.cell_names) - 1)
    summary = {
        "method": "window histogram Shannon entropy + cross-cell population Z-score",
        "paper_doi": "10.1016/j.apenergy.2016.12.143",
        "reproduction_scope": "mechanism with documented formula corrections; not original figure replication",
        "config": asdict(result.config),
        "input_file": input_path.name,
        "input_sha256": hashlib.sha256(input_path.read_bytes()).hexdigest(),
        "rows": len(result.timestamps), "cells": len(result.cell_names),
        "status_counts": {str(k): int(v) for k, v in result.pack_summary["status"].value_counts().items()},
        "pack_level_counts": {str(k): int(v) for k, v in result.pack_summary["pack_level"].value_counts().items()},
        "first_pack_level3_time": None if alarms.empty else alarms.iloc[0]["timestamp"].isoformat(),
        "level3_cells_ever": [name for j, name in enumerate(result.cell_names) if (result.levels[:, j] == 3).any()],
        "event_count": len(events),
        "entropy_upper_bound": math.log(min(result.config.bins, result.config.window), result.config.log_base),
        "internal_zscore_upper_bound": theoretical_z_bound,
        "level2_reachable": theoretical_z_bound > result.config.warning_threshold,
        "level3_reachable": theoretical_z_bound >= result.config.alarm_threshold,
        "level_0_meaning": "not scored; inspect warmup/invalid_window/zero_entropy_std status",
        "label_usage": "No injection metadata or fault labels are read by the diagnostic algorithm.",
        "event_semantics": "Consecutive level>=2 windows; no debounce; span_seconds is last minus first timestamp.",
    }
    (output_dir / "summary.json").write_text(json.dumps(summary, ensure_ascii=False, indent=2, allow_nan=False), encoding="utf-8")
    return summary


def plot_results(voltages: np.ndarray, result: DiagnosticResult, path: Path,
                 title: str, highlights: Sequence[str]) -> None:
    """可选结果图；高亮列只影响显示，不影响检测。"""
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    from matplotlib.colors import BoundaryNorm, ListedColormap

    elapsed = np.asarray((result.timestamps - result.timestamps[0]).total_seconds()) / 3600
    selected = [name for name in highlights if name in result.cell_names]
    fig, axes = plt.subplots(4, 1, figsize=(13, 11), sharex=True, constrained_layout=True)
    arrays = [voltages, result.entropy, result.zscore]
    labels = ["Voltage (V)", f"Entropy (log base {result.config.log_base:g})", "Signed Z-score"]
    for axis, array, ylabel in zip(axes[:3], arrays, labels):
        axis.plot(elapsed, array, color="#64748b", alpha=0.15, linewidth=0.6)
        for name, color in zip(selected, ["#dc2626", "#2563eb", "#7c3aed", "#059669"]):
            axis.plot(elapsed, array[:, result.cell_names.index(name)], label=name, color=color, linewidth=1.3)
        axis.set_ylabel(ylabel)
        axis.grid(alpha=0.18)
        if selected:
            axis.legend(loc="upper left", ncol=4, fontsize=8)
    for threshold, color in ((result.config.warning_threshold, "#d97706"),
                             (result.config.alarm_threshold, "#dc2626")):
        axes[2].axhline(threshold, color=color, linestyle="--", linewidth=0.9)
        axes[2].axhline(-threshold, color=color, linestyle="--", linewidth=0.9)
    cmap = ListedColormap(["#cbd5e1", "#d1fae5", "#fbbf24", "#ef4444"])
    mesh = axes[3].pcolormesh(elapsed, np.arange(1, len(result.cell_names) + 1), result.levels.T,
                              cmap=cmap, norm=BoundaryNorm([-0.5, 0.5, 1.5, 2.5, 3.5], 4), shading="nearest", rasterized=True)
    colorbar = fig.colorbar(mesh, ax=axes[3], ticks=[0, 1, 2, 3], pad=0.01)
    colorbar.ax.set_yticklabels(["Unscored", "Level 1", "Level 2", "Level 3"])
    axes[3].set_ylabel("Cell column index")
    axes[3].set_xlabel("Elapsed time (hours); each score is aligned to window END")
    fig.suptitle(f"{title}\nMechanism reproduction; histogram entropy / population Z-score", fontsize=14)
    fig.savefig(path, dpi=160)
    plt.close(fig)


def main(argv: Sequence[str] | None = None) -> int:
    base = Path(__file__).resolve().parent
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("--input", type=Path, default=base / "data", help="一个宽表 CSV 或含 synthetic_*.csv 的目录")
    parser.add_argument("--output-dir", type=Path, default=base / "results")
    parser.add_argument("--window", type=int, default=100)
    parser.add_argument("--bins", type=int, default=10)
    parser.add_argument("--log-base", type=float, default=2.0)
    parser.add_argument("--warning-threshold", type=float, default=3.5)
    parser.add_argument("--alarm-threshold", type=float, default=4.0)
    parser.add_argument("--std-tolerance", type=float, default=1e-12)
    parser.add_argument("--sample-interval-seconds", type=float, default=10.0)
    parser.add_argument("--gap-factor", type=float, default=1.5)
    parser.add_argument("--plot", action="store_true", help="额外输出诊断 PNG，需要 matplotlib")
    parser.add_argument("--highlight-cells", default="cell_071,cell_062", help="仅用于绘图的逗号分隔列名")
    args = parser.parse_args(argv)
    try:
        config = Config(**{name: getattr(args, name) for name in Config.__dataclass_fields__})
        paths = sorted(args.input.glob("synthetic_*.csv")) if args.input.is_dir() else [args.input]
        if not paths or not all(path.is_file() for path in paths):
            raise ValueError("没有输入 CSV；请先运行 generate_virtual_data.py 或指定 --input")
        if args.plot:
            import importlib.util
            if importlib.util.find_spec("matplotlib") is None:
                raise ValueError("--plot 需要 matplotlib；安装后重试或省略 --plot")
        for path in paths:
            voltages, timestamps, names = load_voltage_csv(path)
            result = diagnose_voltage(voltages, timestamps, config, names)
            destination = args.output_dir / path.stem
            summary = save_results(result, destination, path)
            if args.plot:
                plot_results(voltages, result, destination / "diagnosis.png", path.stem,
                             [item.strip() for item in args.highlight_cells.split(",") if item.strip()])
            print(f"{path.name}: rows={summary['rows']}, cells={summary['cells']}, "
                  f"status={summary['status_counts']}, pack_levels={summary['pack_level_counts']}")
            print(f"  output: {destination}")
        return 0
    except (ValueError, OSError, TypeError) as exc:
        parser.exit(2, f"error: {exc}\n")


if __name__ == "__main__":
    raise SystemExit(main())
