from __future__ import annotations

from dataclasses import dataclass
import numpy as np
from scipy.signal import savgol_filter


@dataclass
class SOCSelector:
    lower: float
    upper: float
    threshold: float
    bins: np.ndarray
    scores: np.ndarray
    smooth: np.ndarray
    counts: np.ndarray
    diagnostic: dict

    def mask(self, soc: np.ndarray) -> np.ndarray:
        return (soc >= self.lower) & ((soc < self.upper) | ((self.upper == 100) & (soc == 100)))


def fit_soc_selector(soc: np.ndarray, voltage: np.ndarray, cfg: dict) -> SOCSelector:
    """Fit on training history only. Sl quantile is an explicit paper ambiguity."""
    bins = np.arange(100)
    b = np.minimum(np.floor(soc).astype(int), 99)
    if np.any((b < 0) | (b > 99)) or not np.isfinite(voltage).all():
        raise ValueError("SOC selector requires clean records")
    spread = voltage.std(axis=1, ddof=0)
    counts = np.bincount(b, minlength=100)
    sums = np.bincount(b, weights=spread, minlength=100)
    valid = counts >= cfg["soc_min_bin_samples"]
    scores = np.divide(sums, counts, out=np.full(100, np.nan), where=counts > 0)
    smooth = np.full(100, np.nan)
    # Never smooth across unobserved SOC bins.
    groups = np.split(np.flatnonzero(valid), np.flatnonzero(np.diff(np.flatnonzero(valid)) > 1) + 1)
    for group in groups:
        if not len(group):
            continue
        win = min(cfg["soc_savgol_window"], len(group) if len(group) % 2 else len(group) - 1)
        smooth[group] = (savgol_filter(scores[group], win, cfg["soc_savgol_order"])
                         if win > cfg["soc_savgol_order"] else scores[group])
    if not valid.any():
        raise ValueError("No SOC bin has enough normal training records")
    sl = float(np.quantile(scores[valid], cfg["soc_floor_quantile"]))
    threshold = max(cfg["soc_lambda"] * float(spread.mean()), sl)
    accepted = np.flatnonzero(valid & (smooth < threshold))
    if not len(accepted):
        raise ValueError("SOC selection is empty; inspect normal baseline and selector settings")
    candidates = np.split(accepted, np.flatnonzero(np.diff(accepted) > 1) + 1)
    # Longest SOC span; a tie picks the lower interval, independent of test data.
    best = max(candidates, key=len)
    diagnostic = {"training_rows": len(soc), "global_mean_spread_v": float(spread.mean()),
                  "sl_v": sl, "sl_definition": f"quantile_{cfg['soc_floor_quantile']}_of_normal_bin_scores",
                  "threshold_v": threshold, "lower_soc": int(best[0]),
                  "upper_soc_exclusive": int(best[-1] + 1), "fit_scope": "training_only"}
    return SOCSelector(float(best[0]), float(best[-1] + 1), threshold, bins, scores,
                       smooth, counts, diagnostic)
