from __future__ import annotations

from dataclasses import dataclass
import warnings
import numpy as np
from scipy.stats import genpareto, kstest
from sklearn.cluster import DBSCAN
from sklearn.neighbors import KernelDensity
from sklearn.preprocessing import StandardScaler

from .features import DOMAIN_SLICES


class InsufficientBaselineError(ValueError):
    """Never silently substitute a fitted-looking probability for an invalid tail."""


def fit_gpd(exceedances: np.ndarray, min_samples: int) -> tuple[float, float, dict]:
    positive = np.asarray(exceedances, dtype=float)
    positive = positive[np.isfinite(positive) & (positive > 0)]
    if len(positive) < min_samples:
        raise InsufficientBaselineError(f"GPD needs >= {min_samples} positive tail samples; got {len(positive)}")
    if np.ptp(positive) <= 1e-12:
        raise InsufficientBaselineError("GPD tail is degenerate")
    with warnings.catch_warnings(record=True) as caught:
        warnings.simplefilter("always")
        shape, _, scale = genpareto.fit(positive, floc=0)
    if not np.isfinite([shape, scale]).all() or scale <= 0:
        raise InsufficientBaselineError("GPD returned invalid parameters")
    support = 1 + shape * positive / scale
    if np.any(support <= 0):
        raise InsufficientBaselineError("GPD support excludes training exceedances")
    # Descriptive KS only: fitted parameters and overlapping windows invalidate
    # the classical fixed-parameter independent-sample p-value interpretation.
    ks = kstest(positive, "genpareto", args=(shape, 0, scale)).statistic
    return float(shape), float(scale), {"n_tail": len(positive), "shape": float(shape),
                                       "scale": float(scale), "descriptive_ks": float(ks),
                                       "fit_warnings": [str(w.message) for w in caught]}


def gpd_probability(gap: np.ndarray, shape: float, scale: float) -> np.ndarray:
    gap = np.maximum(np.asarray(gap, dtype=float), 0)
    if not np.isfinite(gap).all() or not np.isfinite([shape, scale]).all() or scale <= 0:
        raise ValueError("Invalid GPD inputs")
    p = genpareto.cdf(gap, c=shape, loc=0, scale=scale)
    if not np.isfinite(p).all():
        raise ValueError("Non-finite GPD CDF")
    return np.clip(p, 0, 1)


@dataclass
class DomainModel:
    scaler: StandardScaler
    kde: KernelDensity
    tau: float
    shape: float
    scale: float
    diagnostic: dict
    calibration_log_density: np.ndarray
    exceedances: np.ndarray

    @classmethod
    def fit(cls, features: np.ndarray, cfg: dict, calibration_features: np.ndarray | None = None) -> "DomainModel":
        x = np.asarray(features, dtype=float)
        if x.ndim != 2 or not np.isfinite(x).all():
            raise ValueError("Expected finite 2D normal training features")
        scaler = StandardScaler().fit(x)
        z = scaler.transform(x)
        cluster = DBSCAN(eps=cfg["dbscan_eps"], min_samples=cfg["dbscan_min_samples"],
                         n_jobs=1).fit_predict(z)
        keep = cluster != -1
        normal = z[keep]
        minimum = (cfg["min_tail_samples"] / cfg["tail_quantile"]
                   if calibration_features is None else max(30, 5 * x.shape[1]))
        if len(normal) < minimum:
            raise InsufficientBaselineError(f"Only {len(normal)} normal samples after DBSCAN; "
                                            "need a larger baseline for the configured tail fraction")
        h, d = normal.shape
        # Isotropic Silverman factor on z-scored coordinates (explicit formula).
        bandwidth = (h * (d + 2) / 4) ** (-1 / (d + 4))
        kde = KernelDensity(kernel="gaussian", bandwidth=bandwidth, atol=0,
                            rtol=cfg["kde_rtol"], algorithm="ball_tree").fit(normal)
        calibration = normal if calibration_features is None else scaler.transform(calibration_features)
        log_density = kde.score_samples(calibration)
        tau = float(np.quantile(log_density, cfg["tail_quantile"], method="linear"))
        tail = tau - log_density[log_density < tau]
        shape, scale, diagnostic = fit_gpd(tail, cfg["min_tail_samples"])
        diagnostic.update({"n_train": len(x), "n_retained": int(keep.sum()),
                           "removed_fraction": float(1 - keep.mean()), "dimensions": d,
                           "bandwidth": float(bandwidth), "tau": tau,
                           "n_clusters": int(len(set(cluster) - {-1})),
                           "pooling": "all_cells_within_one_vehicle_and_domain",
                           "calibration": ("in_sample_on_DBSCAN_retained_training_features" if calibration_features is None
                                           else "time_held_out_normal_windows_without_DBSCAN_filtering"),
                           "n_calibration": len(calibration),
                           "zero_variance_columns": np.flatnonzero(scaler.var_ == 0).tolist()})
        return cls(scaler, kde, tau, shape, scale, diagnostic, log_density, tail)

    def score(self, features: np.ndarray) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
        z = self.scaler.transform(features)
        log_density = self.kde.score_samples(z)
        gap = np.maximum(self.tau - log_density, 0)
        return log_density, gap, gpd_probability(gap, self.shape, self.scale)


class BatteryRiskModel:
    """One independent model per feature domain and vehicle; no labels accepted."""

    def __init__(self, cfg: dict):
        self.cfg = dict(cfg)
        self.domains: dict[str, DomainModel] = {}

    def fit(self, normal_features: np.ndarray, window_start_s: np.ndarray | None = None,
            window_end_s: np.ndarray | None = None) -> "BatteryRiskModel":
        if normal_features.ndim != 3:
            raise ValueError("Expected [normal_window, cell, feature]")
        calibration = None
        fit_features = normal_features
        if self.cfg.get("calibration_mode", "training_inlier") == "normal_holdout":
            if window_start_s is None or window_end_s is None:
                raise ValueError("Holdout calibration requires window timestamps to prevent overlap")
            split = int(len(normal_features) * (1 - self.cfg["calibration_fraction"]))
            if split < 1 or split >= len(normal_features):
                raise InsufficientBaselineError("Not enough windows for calibration split")
            boundary = window_start_s[split]
            fit_mask = window_end_s < boundary
            calibration = normal_features[split:].reshape(-1, normal_features.shape[-1])
            fit_features = normal_features[fit_mask]
            if len(fit_features) == 0:
                raise InsufficientBaselineError("No non-overlapping fitting windows")
            self.split_diagnostic = {"fit_windows": int(fit_mask.sum()),
                                     "calibration_windows": len(normal_features) - split,
                                     "last_fit_end_s": float(window_end_s[fit_mask].max()),
                                     "first_calibration_start_s": float(boundary)}
        else:
            self.split_diagnostic = {"fit_windows": len(normal_features), "calibration_windows": len(normal_features),
                                     "same_samples_used_for_fit_and_calibration": True}
        x = fit_features.reshape(-1, normal_features.shape[-1])
        for name, columns in DOMAIN_SLICES.items():
            print(f"  Fitting {name}: {len(x)} pooled normal samples", flush=True)
            self.domains[name] = DomainModel.fit(x[:, columns], self.cfg,
                                                  None if calibration is None else calibration[:, columns])
        return self

    def score(self, features: np.ndarray) -> dict[str, np.ndarray]:
        if len(self.domains) != 3:
            raise RuntimeError("Model has not been fitted")
        shape = features.shape[:2]
        x = features.reshape(-1, features.shape[-1])
        result = {}
        probabilities = []
        for name, columns in DOMAIN_SLICES.items():
            density, gap, p = self.domains[name].score(x[:, columns])
            result[f"log_density_{name}"] = density.reshape(shape)
            result[f"gap_{name}"] = gap.reshape(shape)
            result[f"p_{name}"] = p.reshape(shape)
            probabilities.append(result[f"p_{name}"])
        result["fused"] = np.mean(probabilities, axis=0)
        result["risk"] = (result["fused"] >= self.cfg["warning_threshold"]).astype(np.uint8)
        result["risk"] += (result["fused"] >= self.cfg["alarm_threshold"]).astype(np.uint8)
        return result
