"""为 Shannon 熵 + Z-score 算法生成可重复的合成电压输入。

仅用于算法机制测试，不是论文原始数据，也不是经过标定的电化学模型。
注入名称只描述信号特征，不能据此确诊传感器、短路或连接等故障根因。
依赖：Python >= 3.10、numpy、pandas。直接运行即可生成四组 CSV 和 JSON。
"""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
import pandas as pd


START_TIME = "2026-01-01T08:00:00+08:00"
SCENARIOS = ("healthy", "low_entropy", "high_entropy", "common_mode")


def _validate_parameters(
    cells: int, samples: int, interval_seconds: float, seed: int,
    quantization_mv: float,
) -> None:
    if not isinstance(cells, (int, np.integer)) or isinstance(cells, bool) or cells < 2:
        raise ValueError("cells 必须是至少为 2 的整数。")
    if not isinstance(samples, (int, np.integer)) or isinstance(samples, bool) or samples < 6:
        raise ValueError("samples 必须是至少为 6 的整数。默认算法窗口需要至少 100 点。")
    if not np.isfinite(interval_seconds) or interval_seconds <= 0:
        raise ValueError("interval_seconds 必须是有限正数。")
    if not isinstance(seed, (int, np.integer)) or isinstance(seed, bool) or seed < 0:
        raise ValueError("seed 必须是非负整数。")
    if not np.isfinite(quantization_mv) or quantization_mv < 0:
        raise ValueError("quantization_mv 必须是有限非负数；0 表示关闭量化。")


def generate_scenarios(
    cells: int = 100,
    samples: int = 1200,
    interval_seconds: float = 10.0,
    seed: int = 42,
    quantization_mv: float = 10.0,
) -> dict[str, tuple[pd.DataFrame, dict]]:
    """返回 {场景名: (输入 DataFrame, 真值元数据)}，不写文件。

    四场景共享同一正常基线，注入前输入完全相同。小规模试验允许减少
    样本数，注入起点为 min(400, samples // 3)。默认第 400 点起注入。
    JSON 中索引从 0 开始，终点不包含；时间戳保留 +08:00 时区。
    """
    _validate_parameters(cells, samples, interval_seconds, seed, quantization_mv)
    rng = np.random.default_rng(seed)
    seconds = np.arange(samples, dtype=float) * interval_seconds
    times = pd.Timestamp(START_TIME) + pd.to_timedelta(seconds, unit="s")
    cell_ids = [f"cell_{index + 1:03d}" for index in range(cells)]

    # 正电流代表放电。周期负载、简化 SOC 趋势及压降形成所有电芯的共同变化。
    current = 8.0 + 18.0 * np.sin(2 * np.pi * seconds / 1800.0)
    current += 9.0 * np.sin(2 * np.pi * seconds / 430.0)
    discharged_ah = np.r_[0.0, np.cumsum(current[:-1])] * interval_seconds / 3600.0
    soc = np.clip(85.0 - discharged_ah / 120.0 * 100.0, 10.0, 95.0)
    common_voltage = 3.55 + 0.004 * soc - 0.00065 * current
    common_voltage += 0.004 * np.sin(2 * np.pi * seconds / 300.0)

    # 正常电芯也有偏置、轻微漂移和独立测量噪声，不制造完全一致的正常组。
    offsets = rng.normal(0.0, 0.0015, size=cells)
    drift_amplitudes = rng.normal(0.0, 0.0008, size=cells)
    baseline = common_voltage[:, None] + offsets[None, :]
    baseline += np.sin(2 * np.pi * seconds[:, None] / 2400.0) * drift_amplitudes
    baseline += rng.normal(0.0, 0.0008, size=(samples, cells))

    start_index = min(400, samples // 3)
    low_cell_index = min(71, cells) - 1
    high_cell_index = min(62, cells) - 1
    end_exclusive = pd.Timestamp(START_TIME) + pd.to_timedelta(
        samples * interval_seconds, unit="s"
    )

    def injection(kind: str, affected: list[str], **details: object) -> dict:
        return {
            "type": kind,
            "cell_ids": affected,
            "start_index": start_index,
            "end_index_exclusive": samples,
            "start_time": times[start_index].isoformat(),
            "end_time": end_exclusive.isoformat(),
            "time_interval_convention": "[start_time, end_time); end_time 为排他终点",
            **details,
        }

    outputs: dict[str, tuple[pd.DataFrame, dict]] = {}
    for scenario in SCENARIOS:
        voltages = baseline.copy()
        injections: list[dict] = []
        if scenario == "low_entropy":
            # 固定读数使完整注入窗口落入单一箱，熵为零。
            frozen_voltage = float(baseline[start_index, low_cell_index])
            voltages[start_index:, low_cell_index] = frozen_voltage
            injections.append(injection(
                "frozen_voltage_low_entropy", [cell_ids[low_cell_index]],
                frozen_voltage_v_before_quantization=frozen_voltage,
                description="持续固定读数；只定义低分布熵信号，不确定故障根因。",
            ))
        elif scenario == "high_entropy":
            # 独立随机源让注入不受场景遍历次序影响；不根据诊断结果调整参数。
            fault_rng = np.random.default_rng(np.random.SeedSequence([seed, 2026]))
            perturbation = fault_rng.uniform(-0.12, 0.12, size=samples - start_index)
            voltages[start_index:, high_cell_index] += perturbation
            injections.append(injection(
                "broad_distribution_high_entropy", [cell_ids[high_cell_index]],
                perturbation_distribution="uniform", perturbation_min_v=-0.12,
                perturbation_max_v=0.12,
                description="单芯叠加宽分布随机扰动，测试相对高熵信号。",
            ))
        elif scenario == "common_mode":
            # 平移所有电芯。完全位于注入后的窗口中，相对熵特征可能不变。
            # 过渡窗口混合平移前后数据，不能保证瞬态分数与正常场景相同。
            voltages[start_index:, :] += 0.35
            injections.append(injection(
                "common_voltage_shift", cell_ids.copy(), voltage_shift_v=0.35,
                description="所有电芯共同上移，展示相对方法对共模变化的识别边界。",
            ))

        # 先注入再统一量化；0 mV 关闭量化。每个 CSV 只放诊断输入和辅助工况。
        if quantization_mv > 0:
            step_v = quantization_mv / 1000.0
            voltages = np.rint(voltages / step_v) * step_v
        frame = pd.DataFrame(voltages, columns=cell_ids)
        frame.insert(0, "soc_pct", soc)
        frame.insert(0, "current_a", current)
        frame.insert(0, "timestamp", [stamp.isoformat() for stamp in times])
        metadata = {
            "schema_version": 1,
            "scenario": scenario,
            "source": "synthetic; not the paper's original measurements",
            "purpose": "机制测试；合成信号不支持真实诊断准确率或预警提前量结论。",
            "model_limitations": [
                "非经过实验标定的电化学或热模型；不模拟真实故障演化。",
                "正常场景含随机差异及量化效应，不保证诊断结果零误报。",
                "注入类型描述信号特征，不能由此确诊故障根因。",
                "所有场景共享正常基线，不能视作独立车辆测试集。",
            ],
            "parameters": {
                "cells": cells, "samples": samples, "interval_seconds": interval_seconds,
                "seed": seed, "quantization_mv": quantization_mv,
                "start_time": START_TIME, "injection_start_index": start_index,
                "normal_offset_std_v": 0.0015, "normal_noise_std_v": 0.0008,
                "normal_drift_amplitude_std_v": 0.0008,
                "nominal_capacity_ah_for_synthetic_soc": 120.0,
            },
            "units": {"voltage": "V", "current_a": "A", "soc_pct": "%"},
            "current_sign_convention": "positive = discharge; negative = charge",
            "cell_columns": cell_ids,
            "sample_index_convention": "zero-based; intervals are [start, end)",
            "injections": injections,
        }
        outputs[scenario] = (frame, metadata)
    return outputs


def write_scenarios(output_dir: str | Path, **parameters: object) -> list[Path]:
    """写入四对 CSV/JSON 并返回 CSV 路径；同名文件会被覆盖。"""
    scenarios = generate_scenarios(**parameters)
    target = Path(output_dir)
    target.mkdir(parents=True, exist_ok=True)
    paths: list[Path] = []
    for scenario, (frame, metadata) in scenarios.items():
        csv_path = target / f"synthetic_{scenario}.csv"
        # 17 位有效数字避免关闭量化时额外引入隐式四舍五入。
        frame.to_csv(csv_path, index=False, encoding="utf-8-sig", float_format="%.17g")
        metadata["csv_file"] = csv_path.name
        csv_path.with_suffix(".json").write_text(
            json.dumps(metadata, ensure_ascii=False, indent=2, allow_nan=False) + "\n",
            encoding="utf-8",
        )
        paths.append(csv_path)
    return paths


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output-dir", type=Path, default=Path(__file__).parent / "data")
    parser.add_argument("--cells", type=int, default=100)
    parser.add_argument("--samples", type=int, default=1200)
    parser.add_argument("--interval-seconds", type=float, default=10.0)
    parser.add_argument("--seed", type=int, default=42)
    parser.add_argument("--quantization-mv", type=float, default=10.0,
                        help="电压量化步长，单位 mV；0 表示不量化。")
    args = parser.parse_args()
    try:
        paths = write_scenarios(**vars(args))
    except (ValueError, OverflowError) as exc:
        parser.error(str(exc))
    for path in paths:
        print(f"已生成：{path.resolve()}")
    print("标签单独保存在同名 JSON 中；上述数据仅用于合成场景机制测试。")


if __name__ == "__main__":
    main()
