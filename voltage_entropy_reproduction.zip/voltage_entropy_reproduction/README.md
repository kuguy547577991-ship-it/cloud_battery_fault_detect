# 电压异常诊断：虚拟数据与文献算法复现

本目录按“两个 Python 文件”组织：`generate_virtual_data.py` 生成输入，`voltage_fault_diagnosis.py` 包含全部诊断算法及读写、绘图入口。已生成四组示例数据并完成端到端运行，结果在 `results/`。

依据文献：Wang et al., *Voltage fault diagnosis and prognosis of battery systems based on entropy and Z-score for electric vehicles*, Applied Energy 196 (2017), 289–302，DOI：[10.1016/j.apenergy.2016.12.143](https://doi.org/10.1016/j.apenergy.2016.12.143)。

**这是基于虚拟数据的算法机制复现。** 原文分箱和公式存在排版歧义，10 箱设置与部分图中熵值也不一致；本实现采用明确记录的修订，不能据此声称复现了原始车辆曲线或真实预警效果。

## 1. 直接运行

推荐 Python 3.12。在本目录打开终端，依次执行：

```powershell
python -m pip install -r requirements.txt
python generate_virtual_data.py
python voltage_fault_diagnosis.py --plot
```

如果只需要数值结果，最后一条命令省略 `--plot`，此时不需要 matplotlib。两个脚本零参数也都能运行，默认数据和结果路径相对于脚本自身，命令行显式指定的相对路径则相对于终端当前目录。同名输出会覆盖。

如果已有环境的 NumPy、pandas 或可选包存在版本冲突，建议在本目录使用独立环境；不需要激活脚本：

```powershell
python -m venv .venv
.\.venv\Scripts\python.exe -m pip install -r requirements.txt
.\.venv\Scripts\python.exe generate_virtual_data.py
.\.venv\Scripts\python.exe voltage_fault_diagnosis.py --plot
```

运行单个场景：

```powershell
python voltage_fault_diagnosis.py --input data/synthetic_low_entropy.csv --plot
```

改变窗口或对数底数：

```powershell
python voltage_fault_diagnosis.py --window 100 --bins 10 --log-base 2 --plot
```

生成 30 秒间隔数据时，诊断端也需指定对应的采样间隔，以正确判断断档：

```powershell
python generate_virtual_data.py --interval-seconds 30 --output-dir data_30s
python voltage_fault_diagnosis.py --input data_30s --sample-interval-seconds 30 --output-dir results_30s --plot
```

K 是采样点数：K=100 时，10 秒采样首末点跨度为 990 秒；30 秒采样时为 2970 秒。方法按点数统计，不会自动重采样或把两者变成相同物理时长。

## 2. 两个文件如何阅读

### generate_virtual_data.py

- `generate_scenarios(...)`：在内存中返回四组 DataFrame 与对应元数据。
- `write_scenarios(output_dir, ...)`：将数据和标签分开写成 CSV 与 JSON。
- `main()`：解析参数并生成文件。

默认设置：100 个电芯，1200 个采样点，10 秒间隔，随机种子 42，10 mV 量化。时间从 `2026-01-01 08:00:00+08:00` 开始，到 `11:19:50+08:00` 结束。

### voltage_fault_diagnosis.py

- `Config`：参数配置与合法性检查。
- `window_entropy(...)`：共享电压分箱、逐电芯计数和 Shannon 熵，是主要特征计算。
- `entropy_to_scores(...)`：跨电芯总体 Z-score。
- `classify_scores(...)`：阈值分级。
- `diagnose_voltage(...)`：因果滑动窗口与数据质量处理。
- `load_voltage_csv(...)`、`save_results(...)`：输入输出。
- `extract_events(...)`：把连续二/三级窗口整理成事件，便于查看。
- `plot_results(...)`：可选四联图。

核心函数可直接导入，不必通过命令行：

```python
from pathlib import Path
from voltage_fault_diagnosis import Config, load_voltage_csv, diagnose_voltage

voltages, timestamps, cell_names = load_voltage_csv(
    Path("data/synthetic_low_entropy.csv")
)
result = diagnose_voltage(
    voltages, timestamps,
    Config(window=100, bins=10, log_base=2.0),
    cell_names,
)
print(result.pack_summary.tail())
# result.entropy、result.zscore、result.levels 都是 (T,C) 数组。
```

## 3. 虚拟数据包含什么

四组数据共享同一个带正常差异的基线：共同负载和 SOC 趋势、简化电流压降、各电芯小偏置、漂移及测量噪声。这个信号生成方式未经过电化学标定。

| CSV 文件 | 注入设置 | 用途 |
|---|---|---|
| `synthetic_healthy.csv` | 无异常注入，保留正常随机差异和量化 | 观察方法是否误报 |
| `synthetic_low_entropy.csv` | Cell 71 从索引 400 起保持固定读数 | 测试低分布熵异常 |
| `synthetic_high_entropy.csv` | Cell 62 从索引 400 起叠加 ±0.12 V 均匀扰动 | 测试高分布熵异常 |
| `synthetic_common_mode.csv` | 全部电芯从索引 400 起共同上移 0.35 V | 展示相对比较法对共同变化的局限 |

默认注入开始时间是 `09:06:40+08:00`，索引从 0 开始。小样本运行时起点为 `min(400, samples//3)`；减少电芯数量时，目标电芯按代码中的边界约定调整，准确编号记在 JSON 中。

每个同名 JSON 保存参数、种子、受影响电芯、注入类型、起止索引和时间。注入区间采用左闭右开 `[start,end)`，其中 `end_time` 为末个样本之后一个采样间隔。**诊断代码不读取 JSON 标签**，不会利用真值或预先指定的故障电芯决定报警；`--highlight-cells` 只控制画图颜色。

输入宽表格式：

```text
timestamp,current_a,soc_pct,cell_001,cell_002,...,cell_100
2026-01-01T08:00:00+08:00,...,...,3.88,3.88,...,3.88
```

上述行只示意格式。核心输入是时间戳和 `cell_数字` 电压列，单位 V；电流和 SOC 不进入诊断公式。此合成基线不对应论文中的具体电池化学体系，也没有使用论文车辆的绝对过压阈值。

自有数据应按单个车辆/包/簇整理为一个 CSV。电芯列按编号排序；不接受重复列名、重复编号、重复或倒序时间戳。若存在 `asset_id`、`vehicle_id`、`pack_id` 或 `cluster_id` 列，文件内每列必须只有一个组值。所有时间戳需采用一致时区；未带时区的输入保持无时区，不主动推断地域。

## 4. 算法和原文修订约定

对于最近 K 个时间点、C 个电芯构成的窗口 B：

1. 从整个 K×C 窗口求 xmin、xmax，同一窗口的全部电芯共享 L 个等宽箱。
2. 每个电芯沿时间计数，`p[a,j] = count[a,j]/K`。
3. 计算 `E[j] = -sum(p[a,j]*log2(p[a,j]))`。
4. 同窗口跨电芯求均值和总体标准差：`A[j] = (E[j]-mean(E))/std(E,ddof=0)`。
5. 使用 A 的绝对值分级：≤3.5 为一级；>3.5 且 <4 为二级；≥4 为三级。包等级取电芯等级的最大值。

修订和补充包括：原文分箱分母及求和上限按 L 修订；每窗口输出 C 个熵；默认明确使用以 2 为底的对数；`0*log(0)=0`；左闭右开、最后一箱右闭。使用双精度计算，恰好接近分箱边界的数值可能受到浮点舍入影响。

**标准 10 箱熵不应超过 log2(10)≈3.321928。** 本实现检查这一数学性质，没有通过放大系数去模仿原文超过该上界的曲线。只更换统一的对数底数，非退化情况下不会改变 Z-score。

所有分数都标在窗口结束时刻，步长为一个采样点。原文的 12 点雷达图属于展示抽样，本实现保留全部窗口结果。没有引入原文未明确的报警去抖、迟滞、未来电压预测、故障根因分类；也未把 SampEn 对照方法加入主诊断流程。

## 5. 数据质量状态

| status | 含义 | 熵、Z-score 和等级 |
|---|---|---|
| `warmup` | 当前连续片段尚不足 K 点 | 熵/Z 为 NaN；level=0 |
| `invalid_window` | 窗口任一电芯含 NaN 或 Inf | 整窗未评分；level=0 |
| `zero_entropy_std` | 熵的总体标准差 ≤1e-12 | 保留熵；Z 为 NaN；level=0 |
| `ok` | 可正常计算横向 Z-score | 输出 1/2/3 级 |

`level=0` 是工程状态，**不是论文的第四个异常等级，也不是正常或安全判定**。CSV 中的 NaN 保存为空白。

默认相邻时间差超过 `10×1.5=15` 秒时重建窗口；不跨断档拼接样本，不删除电芯、不插值或用 0 V 补缺失。间隔阈值通过配置给定，未使用未来全段数据推断它。

## 6. 输出文件

每个场景对应 `results/synthetic_场景名/`：

| 文件 | 内容 |
|---|---|
| `entropy.csv` | 时间戳与每个电芯的窗口熵 |
| `zscore.csv` | 时间戳与每个电芯的有符号 A |
| `cell_levels.csv` | 每个电芯的 0/1/2/3 状态 |
| `pack_summary.csv` | 窗口起止、质量状态、包等级、最大绝对 A、均值/标准差、分箱范围和异常编号 |
| `events.csv` | 每个电芯连续二/三级窗口的起止、峰值、最大等级及首次三级时间 |
| `summary.json` | 配置、输入 SHA-256、统计计数、理论上界和复现范围 |
| `diagnosis.png` | `--plot` 时生成：电压、熵、有符号 A 和电芯等级热图 |

事件的 `span_seconds` 是最后一个报警窗口时间减去第一个报警窗口时间；单点事件跨度为 0，另有 `n_windows` 表示点数。事件合并不改变逐窗级别，不要求连续触发若干次才报警。

`results/validation_summary.json` 和 `results/test_results.txt` 是本次交付附带的验证快照，不会由常规诊断命令自动更新；改变数据或参数后，不能继续把快照数字当成新运行结果。各场景自己的 `summary.json` 会随运行更新。

## 7. 默认参数的实际运行结果

参数：seed=42、C=100、T=1200、Δt=10 s、K=100、L=10、log2、阈值 3.5/4。34 项独立检查通过，包含逐列 `numpy.histogram` 参考结果、端点、熵上界、阈值边界、零方差、未来数据不影响过去、前缀一致、缺测、断档、时间戳、CSV 校验、合成重现性和事件合并。

| 场景 | 观察到的结果 |
|---|---|
| 低熵 Cell 71 | 注入后首次三级时间 09:10:40，即延迟 240 秒；注入后 800 个有效窗口中 774 个达到三级 |
| 高熵 Cell 62 | 注入后首次三级时间 09:07:50，即延迟 70 秒；注入后 800 个有效窗口中 793 个达到三级 |
| 无注入基线 | 1101 个有效窗口中有 86 个包级三级窗口，合成基线的三级窗口误报占比约 7.81% |
| 全体共同上移 | 1048 个可评分窗口、53 个熵标准差退化窗口；出现 87 个包级三级窗口，不能据此认为检测出了共同上移的物理风险 |

四组均包含最初 99 个未满窗时间点。两种单芯异常在完整包含注入样本的窗口段（索引 499 起）均持续达到三级；这只是本次设定下的结果。

**240 秒和 70 秒是异常信号注入后的检测延迟，不是故障前的预警提前量。** 基线也会误报，已保留原始结果，没有根据输出反向挑选随机种子或调节阈值。相邻窗口重叠，上述比例不是独立样本准确率，也不能作为实际车辆的性能估计。

## 8. 后续应用时的边界

- 输出表示相对电压分布异常，不直接确诊短路、连接故障或采样故障。
- 共模变化、稳定偏置和多芯相似异常可能难以区分；所有电芯熵相同会导致无法评分。
- 内部总体 Z-score 满足 `abs(A)<=sqrt(C-1)`：C≤16 时三级阈值 4 不可达；C≤13 时二级也不可达。
- 本方法没有替代系统的绝对过压/欠压规则。使用自有数据后，应独立验证分组、采样、量化、窗口和阈值。
- 代码在 NumPy 2.3.5/pandas 3.0.1 环境完成 34 项检查；示例图在 NumPy 2.2.6/pandas 3.0.3/matplotlib 3.10.9 环境生成，两次端到端运行的状态与等级计数一致。
