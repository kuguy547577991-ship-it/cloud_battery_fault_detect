from __future__ import annotations

import csv
import gzip
import hashlib
import importlib.metadata
import json
import platform
import time
from pathlib import Path

import joblib
import numpy as np
import pywt

from .config import write_json
from .preprocess import clean_records
from .soc import fit_soc_selector
from .features import extract_features
from .model import BatteryRiskModel
from .evaluation import ground_truth, evaluate_scores, aggregate_metrics, binary_metrics
from .plots import plot_vehicle, plot_counterfactual
from .report import create_report
from .synthetic import SCENARIOS


def save_scores(path: Path, batch, scores: dict, truth: np.ndarray, test: np.ndarray) -> None:
    keys = list(scores)
    with gzip.open(path, "wt", encoding="utf-8", newline="") as stream:
        writer = csv.writer(stream)
        writer.writerow(["window_id", "cell_id", "window_start_s", "window_end_s", "label"] + keys)
        for window in np.flatnonzero(test):
            for cell in range(truth.shape[1]):
                writer.writerow([int(window), cell + 1, float(batch.start_s[window]), float(batch.end_s[window]),
                                 int(truth[window, cell])] + [float(scores[key][window, cell]) for key in keys])


def run_experiment(config: dict, data_dir: str | Path, output: str | Path,
                   counterfactual: bool = True, vehicles: list[str] | None = None,
                   use_soc: bool = True) -> dict:
    data_dir, output = Path(data_dir), Path(output)
    for folder in [output, output / "figures", output / "models", output / "scores", output / "features"]:
        folder.mkdir(parents=True, exist_ok=True)
    cfg = config["method"]
    write_json(output / "resolved_config.json", config)
    versions = {p: importlib.metadata.version(p) for p in
                ["numpy", "scipy", "scikit-learn", "PyWavelets", "matplotlib", "joblib"]}
    write_json(output / "environment.json", {"python": platform.python_version(), "platform": platform.platform(),
                                             "packages": versions,
                                             "max_useful_wavelet_level": pywt.dwt_max_level(cfg["window_length"], cfg["wavelet"]),
                                             "requested_wavelet_level": cfg["wavelet_level"],
                                             "use_soc": use_soc})
    summary = {"seed": config["seed"], "vehicles": {}, "counterfactual": None, "checks": {},
               "calibration_mode": cfg.get("calibration_mode", "training_inlier"), "use_soc": use_soc}
    all_finite, chronological, tails_ok = True, True, True
    t0 = time.perf_counter()
    for name in vehicles or list(SCENARIOS):
        started = time.perf_counter()
        print(f"\n{name}: loading and cleaning", flush=True)
        path = data_dir / f"{name}.npz"
        raw = dict(np.load(path, allow_pickle=False))
        metadata = json.loads(path.with_suffix(".json").read_text(encoding="utf-8"))
        expected_seed = config["seed"] + list(SCENARIOS).index(name) * 1009
        if metadata["seed"] != expected_seed:
            raise ValueError("Dataset seed differs from configured seed; pass the correct --seed or regenerate")
        dt = metadata["sample_seconds"]
        clean = clean_records(raw["time_s"], raw["soc"], raw["voltage_v"], dt)
        # Fixed raw-time-grid cutoff. Removing/reordering future rows cannot move it.
        cutoff_s = metadata["n_samples_clean"] * cfg["train_fraction"] * dt
        train_records = clean.time_s < cutoff_s
        if np.any(ground_truth(clean.time_s[train_records], clean.voltage_v.shape[1], metadata)):
            raise ValueError("Synthetic training period contains an injected fault")
        selector = fit_soc_selector(clean.soc[train_records], clean.voltage_v[train_records], cfg)
        selected = selector.mask(clean.soc) if use_soc else np.ones(len(clean.soc), dtype=bool)
        print(f"  SOC [{selector.lower}, {selector.upper}), retained={selected.mean():.1%}", flush=True)
        batch = extract_features(clean.time_s, clean.voltage_v, selected, cutoff_s, dt, cfg)
        test = ~batch.train
        if not batch.train.any() or not test.any():
            raise ValueError("Training and test windows are both required")
        model = BatteryRiskModel(cfg).fit(batch.values[batch.train], batch.start_s[batch.train], batch.end_s[batch.train])
        scores = model.score(batch.values)
        truth = ground_truth(batch.end_s, clean.voltage_v.shape[1], metadata)
        test_scores = {k: v[test] for k, v in scores.items()}
        metrics = evaluate_scores(batch.end_s[test], test_scores, truth[test], metadata, cfg)
        coverage = np.zeros(len(clean.time_s), dtype=bool)
        coverage[batch.indices[test].ravel()] = True
        test_records = ~train_records
        metrics["coverage"] = {"test_soc_retained_fraction": float(selected[test_records].mean()),
                                "test_window_covered_fraction": float(coverage[test_records].mean()),
                                "n_train_windows": int(batch.train.sum()), "n_test_windows": int(test.sum())}
        metrics["soc"] = selector.diagnostic
        metrics["preprocessing"] = clean.audit
        metrics["domains"] = {key: domain.diagnostic for key, domain in model.domains.items()}
        metrics["normal_fit_calibration_split"] = model.split_diagnostic
        metrics["data_sha256"] = hashlib.sha256(path.read_bytes()).hexdigest()
        joblib.dump({"model": model, "selector": selector, "cutoff_s": cutoff_s}, output / "models" / f"{name}.joblib")
        np.savez_compressed(output / "features" / f"{name}.npz", features=batch.values, train=batch.train,
                            indices=batch.indices, start_s=batch.start_s, end_s=batch.end_s)
        save_scores(output / "scores" / f"{name}.csv.gz", batch, scores, truth, test)
        plot_vehicle(output / "figures", name, clean, selector, batch, scores, model, metadata, cutoff_s, use_soc)
        all_finite &= bool(all(np.isfinite(a).all() for a in scores.values()))
        chronological &= bool(batch.end_s[batch.train].max() < cutoff_s <= batch.start_s[test].min())
        tails_ok &= all(d.diagnostic["n_tail"] >= cfg["min_tail_samples"] for d in model.domains.values())
        if counterfactual and name == "A_progressive":
            print("  Counterfactual: removing injection; keeping the fitted model", flush=True)
            cf_voltage = raw["normal_voltage_v"].copy()
            bad = ~np.isfinite(raw["voltage_v"]) | (raw["voltage_v"] < 0)
            cf_voltage[bad] = raw["voltage_v"][bad]
            cf_clean = clean_records(raw["time_s"], raw["soc"], cf_voltage, dt)
            if not np.array_equal(clean.time_s, cf_clean.time_s):
                raise AssertionError("Counterfactual timestamps changed")
            cf_batch = extract_features(cf_clean.time_s, cf_clean.voltage_v, selected, cutoff_s, dt, cfg)
            if not np.array_equal(batch.indices, cf_batch.indices):
                raise AssertionError("Counterfactual windows changed")
            if not np.array_equal(batch.values[batch.train], cf_batch.values[batch.train]):
                raise AssertionError("Counterfactual changed normal training features")
            cf_scores = model.score(cf_batch.values)
            event = metadata["events"][0]
            cell = event["cell_id"] - 1
            after = batch.end_s >= event["onset_time_s"]
            cf_metrics = binary_metrics(np.zeros_like(truth[test], dtype=bool), cf_scores["fused"][test] >= cfg["warning_threshold"])
            summary["counterfactual"] = {"fault_cell_mean_with_injection": float(scores["fused"][after, cell].mean()),
                                          "fault_cell_mean_without_injection": float(cf_scores["fused"][after, cell].mean()),
                                          "warning_far": cf_metrics["far"],
                                          "identical_training_features": True}
            np.savez_compressed(output / "scores" / "A_counterfactual.npz", end_s=batch.end_s,
                                train=batch.train, actual=scores["fused"], counterfactual=cf_scores["fused"])
            plot_counterfactual(output / "figures", batch.end_s[test], scores["fused"][test], cf_scores["fused"][test], cell)
        metrics["runtime_seconds"] = time.perf_counter() - started
        summary["vehicles"][name] = metrics
        print(f"  Test F1={metrics['warning']['f1']}, FAR={metrics['warning']['far']:.5f}, "
              f"runtime={metrics['runtime_seconds']:.1f}s", flush=True)
        write_json(output / "partial_metrics.json", summary)
    summary["aggregate"] = aggregate_metrics(summary["vehicles"])
    events = [e for v in summary["vehicles"].values() for e in v["events"]]
    summary["checks"] = {
        "all_scores_finite": bool(all_finite),
        "train_test_time_separated": bool(chronological),
        "all_GPD_tails_have_minimum_samples": bool(tails_ok),
        "all_injected_fault_events_warned": all(e["first_warning_time_s"] is not None for e in events),
        "cell_window_FAR_at_most_1_percent": summary["aggregate"]["warning_micro"]["far"] <= 0.01,
    }
    if summary["counterfactual"]:
        cf = summary["counterfactual"]
        summary["checks"]["removing_fault_reduces_fault_cell_score"] = cf["fault_cell_mean_with_injection"] > cf["fault_cell_mean_without_injection"] + 0.2
    summary["runtime_seconds"] = time.perf_counter() - t0
    write_json(output / "metrics.json", summary)
    create_report(output, summary)
    print(f"\nReport: {output / 'validation_report.html'}", flush=True)
    return summary
