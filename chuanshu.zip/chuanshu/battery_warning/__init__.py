"""Synthetic, assumption-explicit reproduction of the KDE-EVT battery method."""

__version__ = "0.1.0"
