from __future__ import annotations

from dataclasses import dataclass
import warnings
import numpy as np
import pywt
from scipy.signal import welch


DOMAIN_SLICES = {"stat": slice(0, 3), "time": slice(3, 5), "freq": slice(5, None)}


def dtw_distances(series: np.ndarray, reference: np.ndarray) -> np.ndarray:
    """Exact unconstrained DTW, absolute local cost, unnormalized path sum.

    All cells run simultaneously; time recursion is the standard dynamic program.
    Input: [time, cell], reference: [time]. No approximation library is used.
    """
    n, cells = series.shape
    previous = np.full((len(reference) + 1, cells), np.inf)
    previous[0] = 0
    for row in range(n):
        current = np.full_like(previous, np.inf)
        for col in range(1, len(reference) + 1):
            cost = np.abs(series[row] - reference[col - 1])
            current[col] = cost + np.minimum(np.minimum(previous[col], current[col - 1]), previous[col - 1])
        previous = current
    return previous[-1]


def spectral_entropy(delta: np.ndarray, sample_seconds: float, cfg: dict) -> np.ndarray:
    _, psd = welch(delta, fs=1 / sample_seconds, window="hann",
                   nperseg=cfg["welch_nperseg"], noverlap=cfg["welch_noverlap"],
                   detrend="constant", scaling="density", axis=0)
    # Equal-width frequency bins -> probability mass = PSD / sum(PSD).
    total = psd.sum(axis=0, keepdims=True)
    p = np.divide(psd, total, out=np.zeros_like(psd), where=total > 0)
    return -np.sum(p * np.log(np.maximum(p, np.finfo(float).tiny)), axis=0)


def window_features(voltage: np.ndarray, sample_seconds: float, cfg: dict) -> np.ndarray:
    if not np.isfinite(voltage).all():
        raise ValueError("Feature windows must be finite")
    reference = np.median(voltage, axis=1)
    delta = voltage - reference[:, None]
    stat = np.column_stack([delta.mean(axis=0), delta.std(axis=0, ddof=0),
                            np.median(np.abs(delta), axis=0)])
    if len(voltage) % cfg["dtw_segments"]:
        raise ValueError("Window cannot be equally divided into DTW segments")
    distances = np.stack([dtw_distances(voltage[idx], reference[idx])
                          for idx in np.split(np.arange(len(voltage)), cfg["dtw_segments"])])
    sd = distances.std(ddof=0)
    zmax = ((distances - distances.mean()) / sd).max(axis=0) if sd > 1e-15 else np.zeros(voltage.shape[1])
    temporal = np.column_stack([distances.mean(axis=0), zmax])
    # Paper table implies level=4. Explicit extension mode is recorded in config.
    # Boundary effects are reported once in the run metadata, not per window.
    with warnings.catch_warnings():
        warnings.filterwarnings("ignore", message="Level value of .* is too high")
        coeffs = pywt.wavedec(delta, cfg["wavelet"], mode=cfg["wavelet_mode"],
                              level=cfg["wavelet_level"], axis=0)
    energies = np.column_stack([np.sum(c**2, axis=0) for c in coeffs])
    entropy = spectral_entropy(delta, sample_seconds, cfg)
    result = np.column_stack([stat, temporal, energies, entropy])
    if not np.isfinite(result).all():
        raise ValueError("Non-finite feature values")
    return result


@dataclass
class FeatureBatch:
    values: np.ndarray
    indices: np.ndarray
    train: np.ndarray
    start_s: np.ndarray
    end_s: np.ndarray


def make_windows(time_s: np.ndarray, selected: np.ndarray, cutoff_s: float,
                 sample_seconds: float, cfg: dict) -> tuple[np.ndarray, np.ndarray]:
    windows, training = [], []
    for is_train, phase in [(True, time_s < cutoff_s), (False, time_s >= cutoff_s)]:
        index = np.flatnonzero(selected & phase)
        if not len(index):
            continue
        breaks = (np.flatnonzero(np.diff(time_s[index]) > sample_seconds * cfg["max_gap_factor"]) + 1
                  if cfg["window_policy"] == "contiguous" else np.array([], dtype=int))
        for segment in np.split(index, breaks):
            for start in range(0, len(segment) - cfg["window_length"] + 1, cfg["window_step"]):
                windows.append(segment[start:start + cfg["window_length"]])
                training.append(is_train)
    if not windows:
        raise ValueError("No complete analysis windows")
    return np.stack(windows), np.asarray(training, dtype=bool)


def extract_features(time_s: np.ndarray, voltage: np.ndarray, selected: np.ndarray,
                     cutoff_s: float, sample_seconds: float, cfg: dict) -> FeatureBatch:
    indices, training = make_windows(time_s, selected, cutoff_s, sample_seconds, cfg)
    values = []
    for i, index in enumerate(indices):
        values.append(window_features(voltage[index], sample_seconds, cfg))
        if (i + 1) % 100 == 0:
            print(f"  Features {i + 1}/{len(indices)} windows", flush=True)
    return FeatureBatch(np.stack(values), indices, training,
                        time_s[indices[:, 0]], time_s[indices[:, -1]])
