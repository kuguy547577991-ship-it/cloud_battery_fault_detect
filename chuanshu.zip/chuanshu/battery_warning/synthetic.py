"""Generate voltage signatures, not an electrochemical or thermal-runaway simulator.

All mechanisms and labels are defined before fitting the detector. The first 30%
is normal. Fault-free counterfactual voltage is retained for paired validation.
"""
from __future__ import annotations

from pathlib import Path
import numpy as np
from scipy.signal import lfilter

from .config import write_json


SCENARIOS = {
    "A_progressive": "progressive voltage drop with growing oscillation",
    "B_two_faults": "self-discharge-like drift and intermittent short-like dips",
    "C_mild": "persistent mild inconsistency",
    "D_healthy": "healthy pack with SOC-edge polarization and load transients",
}


def simulate_vehicle(config: dict, vehicle_id: str, vehicle_index: int) -> dict:
    s = config["simulation"]
    n, cells, dt = s["n_samples"], s["n_cells"], s["sample_seconds"]
    seed = config["seed"] + vehicle_index * 1009
    rng = np.random.default_rng(seed)
    k = np.arange(n)
    time_s = k * dt
    phase = (k % s["cycle_samples"]) / s["cycle_samples"]
    soc = 5 + 90 * (1 - np.abs(2 * phase - 1))
    direction = np.where(phase < 0.5, -1.0, 1.0)
    current = direction * (30 + 12 * np.sin(k / 37) ** 2)
    current += 5 * np.sin(k / 9)
    z = soc / 100
    # Shared OCV curve with steeper SOC edges; current > 0 means discharge.
    ocv = 3.28 + 0.77 * z + 0.10 * np.tanh((z - 0.10) * 18)
    ocv += 0.08 * np.tanh((z - 0.90) * 18)
    shared = ocv - current * 0.0011 + 0.002 * np.sin(k / 83)
    offset = rng.normal(0, 0.0010, cells)
    resistance_delta = rng.normal(0, 0.000012, cells)
    soc_heterogeneity = rng.normal(0, 1, cells)
    edge = np.exp(-z / 0.10) + np.exp(-(1 - z) / 0.10)
    ar = lfilter([1], [1, -0.88], rng.normal(size=(n, cells)), axis=0)
    ar *= np.sqrt(1 - 0.88**2)
    normal = shared[:, None] + offset - current[:, None] * resistance_delta
    normal += 0.018 * edge[:, None] * soc_heterogeneity
    normal += (0.00065 + 0.0008 * edge[:, None]) * ar
    normal += rng.normal(0, 0.0003, (n, cells))
    voltage = normal.copy()
    # Severity labels: 0=normal, 1=injected incipient fault, 2=injected severe fault.
    labels = np.zeros((n, cells), dtype=np.uint8)
    injections = np.zeros_like(voltage)
    events = []

    def add_fault(cell: int, onset_fraction: float, kind: str, amplitude: np.ndarray,
                  critical_fraction: float | None) -> None:
        onset = int(n * onset_fraction)
        injections[:, cell] += amplitude
        labels[onset:, cell] = 1
        critical = None if critical_fraction is None else int(n * critical_fraction)
        if critical is not None:
            labels[critical:, cell] = 2
        events.append({"cell_id": cell + 1, "kind": kind,
                       "onset_index": onset, "onset_time_s": int(time_s[onset]),
                       "critical_index": critical,
                       "critical_time_s": None if critical is None else int(time_s[critical])})

    if vehicle_id == "A_progressive":
        progress = np.clip((k / n - 0.55) / 0.45, 0, 1)
        a = -0.070 * progress**1.25
        a += 0.006 * progress * np.sin(k * 0.49)
        add_fault(min(73, cells - 1), 0.55, "progressive_drop", a, 0.82)
    elif vehicle_id == "B_two_faults":
        progress = np.clip((k / n - 0.50) / 0.50, 0, 1)
        add_fault(1, 0.50, "self_discharge_signature", -0.045 * progress, 0.85)
        progress = np.clip((k / n - 0.65) / 0.35, 0, 1)
        pulses = (np.sin(k / 19) > 0.25).astype(float)
        a = -progress * (0.018 + 0.055 * pulses)
        add_fault(min(48, cells - 2), 0.65, "intermittent_short_signature", a, 0.85)
    elif vehicle_id == "C_mild":
        progress = np.clip((k / n - 0.58) / 0.12, 0, 1)
        a = -0.006 * progress + 0.0006 * progress * np.sin(k / 11)
        add_fault(min(19, cells - 1), 0.58, "mild_inconsistency", a, None)
    elif vehicle_id != "D_healthy":
        raise ValueError(vehicle_id)

    voltage += injections
    resolution = s["measurement_resolution_v"]
    voltage = np.round(voltage / resolution) * resolution
    normal = np.round(normal / resolution) * resolution
    fault_delta = voltage - normal
    original_index = k.copy()
    metadata = {"vehicle_id": vehicle_id, "description": SCENARIOS[vehicle_id],
                "seed": seed, "n_cells": cells, "n_samples_clean": n,
                "sample_seconds": dt, "events": events,
                "physics_scope": "synthetic voltage signatures; no actual short circuit or thermal model"}
    # Deliberate issues are far from fault onset and the train/test boundary.
    if s["inject_data_quality_issues"]:
        voltage[205:207, 3] = np.nan
        voltage[1210:1215, 4] = np.nan
        voltage[1570, 5] = -1.0
        soc[1650] = 110.0
        keep = np.ones(n, dtype=bool)
        keep[820:822] = False
        keep[1820:1826] = False
        arrays = [time_s, soc, current, voltage, labels, normal, fault_delta, original_index]
        arrays = [a[keep] for a in arrays]
        # Include a duplicate record and scramble raw order.
        idx = np.r_[np.arange(len(arrays[0])), 350]
        rng.shuffle(idx)
        time_s, soc, current, voltage, labels, normal, fault_delta, original_index = [a[idx] for a in arrays]
    return {"time_s": time_s, "soc": soc, "current_a": current,
            "voltage_v": voltage, "labels": labels, "normal_voltage_v": normal,
            "fault_delta_v": fault_delta, "original_index": original_index,
            "metadata": metadata}


def generate_dataset(config: dict, destination: str | Path) -> list[Path]:
    destination = Path(destination)
    destination.mkdir(parents=True, exist_ok=True)
    files = []
    for i, name in enumerate(SCENARIOS):
        data = simulate_vehicle(config, name, i)
        metadata = data.pop("metadata")
        path = destination / f"{name}.npz"
        np.savez_compressed(path, **data)
        write_json(path.with_suffix(".json"), metadata)
        files.append(path)
        print(f"Generated {name}: {len(data['time_s'])} raw rows x {data['voltage_v'].shape[1]} cells", flush=True)
    write_json(destination / "generation_config.json", config)
    return files
