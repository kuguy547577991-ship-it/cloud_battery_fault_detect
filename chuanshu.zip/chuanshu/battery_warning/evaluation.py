from __future__ import annotations

import numpy as np


def ground_truth(time_s: np.ndarray, cells: int, metadata: dict) -> np.ndarray:
    """Synthetic truth from injection schedule, never from detector scores."""
    truth = np.zeros((len(time_s), cells), dtype=np.uint8)
    for event in metadata["events"]:
        cell = event["cell_id"] - 1
        truth[time_s >= event["onset_time_s"], cell] = 1
        if event["critical_time_s"] is not None:
            truth[time_s >= event["critical_time_s"], cell] = 2
    return truth


def binary_metrics(truth: np.ndarray, prediction: np.ndarray) -> dict:
    truth, prediction = np.asarray(truth, dtype=bool), np.asarray(prediction, dtype=bool)
    tp = int(np.sum(truth & prediction))
    fp = int(np.sum(~truth & prediction))
    fn = int(np.sum(truth & ~prediction))
    tn = int(np.sum(~truth & ~prediction))
    precision = tp / (tp + fp) if tp + fp else None
    recall = tp / (tp + fn) if tp + fn else None
    f1 = 2 * tp / (2 * tp + fp + fn) if 2 * tp + fp + fn else None
    return {"tp": tp, "fp": fp, "fn": fn, "tn": tn,
            "precision": precision, "recall": recall, "f1": f1,
            "far": fp / (fp + tn) if fp + tn else None}


def evaluate_scores(end_s: np.ndarray, scores: dict, truth: np.ndarray,
                    metadata: dict, cfg: dict) -> dict:
    p = scores["fused"]
    warning, alarm = p >= cfg["warning_threshold"], p >= cfg["alarm_threshold"]
    result = {"warning": binary_metrics(truth > 0, warning),
              "alarm_vs_any_fault": binary_metrics(truth > 0, alarm),
              "critical_recall": float(alarm[truth == 2].mean()) if np.any(truth == 2) else None,
              "critical_tp": int(np.sum(alarm & (truth == 2))),
              "critical_fn": int(np.sum(~alarm & (truth == 2))),
              "label_policy": "window_endpoint_severity",
              "test_windows": len(end_s), "cell_windows": int(p.size)}
    # Pack-level nuisance rate can be much higher than per-cell FAR.
    all_normal = ~(truth > 0).any(axis=1)
    result["pack_false_warning_window_rate"] = (float(warning[all_normal].any(axis=1).mean())
                                                 if all_normal.any() else None)
    any_fault = (truth > 0).any(axis=1)
    top = np.argmax(p, axis=1)
    localized = (truth[np.arange(len(truth)), top] > 0) & warning.any(axis=1)
    result["top1_localization_recall"] = float(localized[any_fault].mean()) if any_fault.any() else None
    result["domain_ablation"] = {
        domain: binary_metrics(truth > 0, scores[f"p_{domain}"] >= cfg["warning_threshold"])
        for domain in ("stat", "time", "freq")}
    events = []
    for event in metadata["events"]:
        cell = event["cell_id"] - 1
        valid = end_s >= event["onset_time_s"]
        item = dict(event)
        for name, threshold in [("warning", cfg["warning_threshold"]), ("alarm", cfg["alarm_threshold"])]:
            hits = np.flatnonzero(valid & (p[:, cell] >= threshold))
            first = float(end_s[hits[0]]) if len(hits) else None
            item[f"first_{name}_time_s"] = first
            item[f"{name}_delay_seconds"] = None if first is None else first - event["onset_time_s"]
        critical = event["critical_time_s"]
        first = item["first_warning_time_s"]
        item["warning_lead_to_injected_severe_hours"] = ((critical - first) / 3600
                                                        if critical is not None and first is not None else None)
        item["pre_onset_false_warning_windows"] = int(np.sum((end_s < event["onset_time_s"]) & warning[:, cell]))
        # Require 3 positive windows with no gap over 2 window steps (report only).
        sustained = None
        for j in range(2, len(end_s)):
            if (valid[j - 2:j + 1].all() and warning[j - 2:j + 1, cell].all()
                    and np.all(np.diff(end_s[j - 2:j + 1]) <= 2 * cfg["window_step"] * metadata["sample_seconds"])):
                sustained = float(end_s[j])
                break
        item["three_window_confirmation_time_s"] = sustained
        events.append(item)
    result["events"] = events
    return result


def aggregate_metrics(vehicles: dict) -> dict:
    summed = {key: sum(v["warning"][key] for v in vehicles.values()) for key in ("tp", "fp", "fn", "tn")}
    tp, fp, fn, tn = [summed[k] for k in ("tp", "fp", "fn", "tn")]
    values = [v["warning"]["f1"] for v in vehicles.values() if v["warning"]["f1"] is not None]
    cri_tp = sum(v["critical_tp"] for v in vehicles.values())
    cri_fn = sum(v["critical_fn"] for v in vehicles.values())
    return {"warning_micro": {**summed, "precision": tp / (tp + fp) if tp + fp else None,
                               "recall": tp / (tp + fn) if tp + fn else None,
                               "f1": 2 * tp / (2 * tp + fp + fn) if 2 * tp + fp + fn else None,
                               "far": fp / (fp + tn) if fp + tn else None},
            "warning_macro_f1_defined_vehicles": float(np.mean(values)) if values else None,
            "critical_recall_micro": cri_tp / (cri_tp + cri_fn) if cri_tp + cri_fn else None,
            "critical_tp": cri_tp, "critical_fn": cri_fn}
