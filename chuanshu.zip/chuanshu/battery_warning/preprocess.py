from __future__ import annotations

from dataclasses import dataclass
import numpy as np


@dataclass
class CleanData:
    time_s: np.ndarray
    soc: np.ndarray
    voltage_v: np.ndarray
    audit: dict


def clean_records(time_s: np.ndarray, soc: np.ndarray, voltage_v: np.ndarray,
                  sample_seconds: float, max_missing: int = 3) -> CleanData:
    """Sort/deduplicate and interpolate short gaps only. Labels never enter here.

    Reindex to the stated sampling grid; discard long gaps and physically invalid
    observed rows. Interpolation requires the right endpoint (offline repair).
    """
    t, s, v = np.asarray(time_s), np.asarray(soc), np.asarray(voltage_v)
    if t.ndim != 1 or s.shape != t.shape or v.ndim != 2 or v.shape[0] != len(t):
        raise ValueError("Inconsistent input shapes")
    if sample_seconds <= 0 or not np.isfinite(t).all():
        raise ValueError("Invalid sampling interval or timestamps")
    order = np.argsort(t, kind="stable")
    t, s, v = t[order], s[order], v[order]
    unique, first = np.unique(t, return_index=True)
    duplicate_count = len(t) - len(unique)
    t, s, v = unique, s[first], v[first]
    grid_index_float = (t - t[0]) / sample_seconds
    if not np.allclose(grid_index_float, np.rint(grid_index_float), atol=1e-5):
        raise ValueError("Timestamps must lie on the sampling grid; resample explicitly first")
    grid_index = np.rint(grid_index_float).astype(int)
    grid = t[0] + np.arange(grid_index[-1] + 1) * sample_seconds
    values = np.full((len(grid), v.shape[1] + 1), np.nan)
    values[grid_index] = np.column_stack([s, v])
    invalid_observed = ((s < 0) | (s > 100) | (v < 0).any(axis=1)
                        | np.isinf(s) | np.isinf(v).any(axis=1))
    invalid_grid = np.zeros(len(grid), dtype=bool)
    invalid_grid[grid_index[invalid_observed]] = True
    values[invalid_grid] = np.nan
    filled = 0
    for col in range(values.shape[1]):
        missing = ~np.isfinite(values[:, col])
        starts = np.flatnonzero(missing & ~np.r_[False, missing[:-1]])
        ends = np.flatnonzero(missing & ~np.r_[missing[1:], False]) + 1
        for a, b in zip(starts, ends):
            if b - a <= max_missing and a > 0 and b < len(grid) and not invalid_grid[a:b].any():
                values[a:b, col] = np.linspace(values[a - 1, col], values[b, col], b - a + 2)[1:-1]
                filled += b - a
    valid = np.isfinite(values).all(axis=1) & ~invalid_grid
    audit = {"raw_rows": len(time_s), "duplicate_rows_removed": duplicate_count,
             "sampling_grid_rows": len(grid), "missing_timestamps": len(grid) - len(t),
             "invalid_observed_rows": int(invalid_observed.sum()),
             "interpolated_scalar_values": filled,
             "rows_discarded_on_grid": int((~valid).sum()), "clean_rows": int(valid.sum()),
             "remaining_time_gaps": int(np.sum(np.diff(grid[valid]) > 1.5 * sample_seconds))}
    return CleanData(grid[valid], values[valid, 0], values[valid, 1:], audit)
