# -*- coding: utf-8 -*-
"""
Created on Sun May 12 17:56:34 2024

@author: SW Lee
"""
import torch
from torch.nn import Linear
import torch.nn.functional as F
from torch_geometric.nn import SAGEConv
from torch_geometric.nn import global_max_pool
import numpy as np
from torch import nn

#%%
class GraphSAGE(torch.nn.Module):
    def __init__(self, hidden_channels):
        super(GraphSAGE, self).__init__()
        self.conv1 = SAGEConv(100, 32)
        self.bn1 = nn.BatchNorm1d(32)
        self.conv2 = SAGEConv(32, hidden_channels)
        self.bn2 = nn.BatchNorm1d(hidden_channels)
        self.conv3 =SAGEConv(hidden_channels, hidden_channels)
        self.bn3 = nn.BatchNorm1d(hidden_channels)
        
        self.lin = Linear(hidden_channels, 2)

    def forward(self, x, edge_index, batch):
        # 1. Obtain node embeddings
        x = self.conv1(x, edge_index)
        x = self.bn1(x)
        x = x.relu()
        x = self.conv2(x, edge_index)
        x = self.bn2(x)
        x = x.relu()
        x = self.conv3(x, edge_index)
        x = self.bn3(x)
        x = x.relu()

        # 2. Readout layer
        x = global_max_pool(x, batch)
        x = F.dropout(x, p=0.2, training=self.training)
        x = self.lin(x)
        x = F.softmax(x,dim=1)

        return x
#%%    
device = 'cuda'
model0 = GraphSAGE(hidden_channels=32)
model1 = GraphSAGE(hidden_channels=32)
model2 = GraphSAGE(hidden_channels=32)
model3 = GraphSAGE(hidden_channels=32)
optimizer0 = torch.optim.Adam(model0.parameters(), lr=8e-5,weight_decay=0.01)
optimizer1 = torch.optim.Adam(model1.parameters(), lr=8e-5,weight_decay=0.01)
optimizer2 = torch.optim.Adam(model2.parameters(), lr=8e-5,weight_decay=0.01)
optimizer3 = torch.optim.Adam(model3.parameters(), lr=8e-5,weight_decay=0.01)
weight=torch.from_numpy(np.array([0.05,1])).float()
criterion = torch.nn.CrossEntropyLoss(weight=weight).to(device)
model0.cuda()
model1.cuda()
model2.cuda()
model3.cuda()
#%%
def train_each(model,data_loader,optimizer):
    model.train()
    # 把模型设置为训练模式
    train_batch_num=len(data_loader)
    total_loss=0
    correct=0
    sample_num=0
    for data in data_loader:  # Iterate in batches over the training dataset.
        out = model(data.x.to(device), data.edge_index.to(device), data.batch.to(device))
        loss = criterion(out, data.y.to(device))  # Compute the loss.
        loss.backward()  # Derive gradients.
        #  计算梯度
        optimizer.step()  # Update parameters based on gradients.
        #  根据上面计算的梯度更新参数
        optimizer.zero_grad()  # Clear gradients.
        #  清除梯度，为下一个批次的数据做准备，相当于从头开始
        total_loss +=loss.item()
        pred= out.argmax(dim=1)
        correct+= int((pred == data.y.to(device)).sum())
        sample_num+=len(pred)
    loss=total_loss/train_batch_num
    acc=correct/sample_num
    return loss,acc
def train(model0,model1,model2,model3,train_loader0,train_loader1,train_loader2,train_loader3):
    result0=train_each(model0,train_loader0,optimizer0)
    result1=train_each(model1,train_loader1,optimizer1)
    result2=train_each(model2,train_loader2,optimizer2)
    result3=train_each(model3,train_loader3,optimizer3)
    return result0,result1,result2,result3

def test_each(model,data_loader):
    model.eval()
    # 把模型设置为评估模式
    test_batch_num=len(data_loader)
    total_loss=0
    correct=0
    sample_num=0
    out_all=[]
    with torch.no_grad():
        for i,data in enumerate(data_loader):  
            out = model(data.x.to(device), data.edge_index.to(device), data.batch.to(device))
            out_all.append(out)
            loss= criterion(out, data.y.to(device))
            total_loss +=loss.item()
            pred = out.argmax(dim=1)  # Use the class with highest probability.
            correct += int((pred == data.y.to(device)).sum())  # Check against ground-truth labels.
            sample_num+=len(pred)
    out_all_v=torch.vstack(out_all)
    loss=total_loss/test_batch_num
    acc=correct/sample_num
    return loss,acc,out_all_v

def test(model0,model1,model2,model3,data_loader,y_all_t):
    correct=0
    result0=test_each(model0,data_loader)
    result1=test_each(model1,data_loader)
    result2=test_each(model2,data_loader)
    result3=test_each(model3,data_loader)
    out_sum=result0[2]+result1[2]+result2[2]+result3[2]
    out_mean=out_sum/4
    pred = out_mean.argmax(dim=1)  # Use the class with highest probability.
    correct = int((pred == y_all_t.to(device)).sum())  # Check against ground-truth labels.
    acc=correct/len(pred)
    return result0,result1,result2,result3,acc

#%%
train_loss_list=[]
train_acc_list=[]
test_loss_list=[]
test_acc_list=[]
test_acc_list_final=[]

valid_acc_list=[]

epochs=300
for epoch in range(epochs):
    train_result0,train_result1,train_result2,train_result3=train(
        model0,model1,model2,model3,train_loader0,train_loader1,train_loader2,train_loader3)
    train_loss_list.append(np.hstack((train_result0[0],train_result1[0],train_result2[0],train_result3[0])))
    train_acc_list.append(np.hstack((train_result0[1],train_result1[1],train_result2[1],train_result3[1])))
    
    test_result0,test_result1,test_result2,test_result3,test_acc=test(model0,model1,model2,model3,test_loader,y_all_t)
    test_loss_list.append(np.hstack((test_result0[0],test_result1[0],test_result2[0],test_result3[0])))                   
    test_acc_list.append(np.hstack((test_result0[1],test_result1[1],test_result2[1],test_result3[1])))
    test_acc_list_final.append(test_acc)  
    
    valid_result0,valid_result1,valid_result2,valid_result3,valid_acc=test(model0,model1,model2,model3,valid_loader,y_all_valid_t) 
    valid_acc_list.append(valid_acc)